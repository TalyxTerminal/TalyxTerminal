"""Base Portfolio module."""

# Copyright (c) 2023-2026
# Author: Hugo Delatte <hugo.delatte@skfoliolabs.com>
# SPDX-License-Identifier: BSD-3-Clause

# The Portfolio class contains more than 40 measures that can be computationally
# expensive. The use of __slots__ instead of __dict__ is based on the following
# consideration:
#   * Fast Portfolio instantiation.
#   * Compute a measure only when needed.
#   * Reuse the measures functions in measures.py module independently of the
#     Portfolio class.
#   * Have the measures as Class attributes and not as Class generic
#     methods for better usability.
#   * Caching of the 40 measures.
#   * DRY by not re-writing @cached_property decorated methods for all the 40 measures.
#
# We define 7 types of attributes:
#     * Public (read and write)
#     * Private (read and write for private usage)
#     * Read-only (handled in __setattr__)
#     * Global and local measures arguments: when they change, we clear the cache of
#       all the measures (handled in __setattr__)
#     * Attributes with custom getter and setter (using @property + private name
#       in __slots__)
#     * Attributes with custom getter without setter (read-only) that caches the result
#       (using custom decorator @cached_property_slots + private name in __slots__)
#     * Measures that are cached (handled in __getattribute__)
#
#  In order to generate the measures attributes we call the measure functions and their
#  arguments dynamically from the measures.py module. The function arguments are
#  retrieved from the class attributes following the below rules:
#     * Global measures function arguments (defined in GLOBAL_ARGS) need to be defined
#       in the class attributes with identical name.
#     * Local measures function arguments (defined in LOCAL_ARGS) need to be defined in
#       the class attributes with the argument name preceded by the measure name and
#       separated by '_'.

from __future__ import annotations

import warnings
from abc import abstractmethod
from functools import partial
from types import FunctionType
from typing import TYPE_CHECKING, Any, ClassVar

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import scipy.stats as st

import skfolio.typing as skt
from skfolio import measures as mt
from skfolio._constants import _ANNUALIZATION_FACTOR_DEFAULT, _RISK_FREE_RATE
from skfolio.measures import (
    ExtraRiskMeasure,
    PerfMeasure,
    RatioMeasure,
    RiskMeasure,
)
from skfolio.typing import FloatArray, IntArray
from skfolio.utils.sorting import dominate
from skfolio.utils.tools import (
    _validate_positive_integer,
    _validate_sample_weight,
    args_names,
    cached_property_slots,
    format_measure,
    optimal_rounding_decimals,
)

if TYPE_CHECKING:
    from typing_extensions import Self

_ZERO_THRESHOLD = 1e-5
_MEASURES = {
    e for enu in [PerfMeasure, RiskMeasure, ExtraRiskMeasure, RatioMeasure] for e in enu
}
_MEASURES_VALUES = {e.value: e for e in _MEASURES}

_MEASURE_LOCAL_PARAMS = frozenset(
    {
        "value_at_risk_beta",
        "cvar_beta",
        "entropic_risk_measure_theta",
        "entropic_risk_measure_beta",
        "evar_beta",
        "drawdown_at_risk_beta",
        "cdar_beta",
        "edar_beta",
    }
)
_MEASURE_GLOBAL_PARAMS = frozenset(
    {
        "min_acceptable_return",
        "compounded",
        _RISK_FREE_RATE,
    }
)
_PORTFOLIO_MEASURE_PARAMS = (
    _MEASURE_GLOBAL_PARAMS
    | _MEASURE_LOCAL_PARAMS
    | {"annualization_factor", "fitness_measures"}
)


class BasePortfolio:
    r"""Base Portfolio class for all portfolios in skfolio.

    Parameters
    ----------
    returns : array-like of shape (n_observations,)
        Vector of portfolio returns.

    observations : array-like of shape (n_observations,)
        Vector of portfolio observations.

    name : str, optional
        Name of the portfolio.
        The default (`None`) is to use the object id.

    tag : str, optional
        Tag given to the portfolio.
        Tags are used to manipulate groups of Portfolios from a `Population`.

    fitness_measures : list[measures], optional
        List of fitness measures.
        Fitness measures are used to compute the portfolio fitness which is used to
        compute domination.
        The default (`None`) is to use the list [PerfMeasure.MEAN, RiskMeasure.VARIANCE]

    annualization_factor : float, default=252.0
        Factor used to annualize the below measures using the square-root rule:

            * Annualized Mean = Mean * factor
            * Annualized Variance = Variance * factor
            * Annualized Semi-Variance = Semi-Variance * factor
            * Annualized Standard-Deviation = Standard-Deviation * sqrt(factor)
            * Annualized Semi-Deviation = Semi-Deviation * sqrt(factor)
            * Annualized Sharpe Ratio = Sharpe Ratio * sqrt(factor)
            * Annualized Sortino Ratio = Sortino Ratio * sqrt(factor)

    risk_free_rate : float, default=0.0
        Risk-free rate, expressed in the same frequency as the returns (for example,
        :math:`0.04 / 252` for a 4% annual rate with daily returns).
        The default value is `0.0`.

    compounded : bool, default=False
        If this is set to True, cumulative returns are compounded.
        The default is `False`.

    sample_weight : ndarray of shape (n_observations,), optional
        Finite, nonnegative observation probabilities. The weights must sum to
        one within an absolute tolerance of 1.001e-5. If None, equal weights are assumed.

    min_acceptable_return : float, optional
        The minimum acceptable return used to distinguish "downside" and "upside"
        returns for the computation of lower partial moments:

            * First Lower Partial Moment
            * Semi-Variance
            * Semi-Deviation

        The default (`None`) is to use the mean.

    value_at_risk_beta : float, default=0.95
        The confidence level of the Portfolio VaR (Value At Risk) which represents
        the return on the worst (1-beta)% observations.
        The default value is `0.95`.

    entropic_risk_measure_theta : float, default=1.0
        The risk aversion level of the Portfolio Entropic Risk Measure.
        The default value is `1.0`.

    entropic_risk_measure_beta : float, default=0.95
        The confidence level of the Portfolio Entropic Risk Measure.
        The default value is `0.95`.

    cvar_beta : float, default=0.95
        Confidence level of CVaR (Conditional Value at Risk), between 0 and 1,
        inclusive. CVaR averages the worst `1 - beta` probability mass.
        At 1, CVaR equals the largest loss with positive sample weight.

    evar_beta : float, default=0.95
        The confidence level of the Portfolio EVaR (Entropic Value at Risk).
        The default value is `0.95`.

    drawdown_at_risk_beta : float, default=0.95
        The confidence level of the Portfolio Drawdown at Risk (DaR) which represents
        the drawdown on the worst (1-beta)% observations.
        The default value is `0.95`.

    cdar_beta : float, default=0.95
        Confidence level of CDaR (Conditional Drawdown at Risk), between 0 and 1,
        inclusive. CDaR averages the worst drawdowns over probability `1 - beta`.
        At 1, CDaR equals the largest drawdown magnitude with positive sample weight.

    edar_beta : float, default=0.95
        The confidence level of the Portfolio EDaR (Entropic Drawdown at Risk).
        The default value is `0.95`.

    Attributes
    ----------
    n_observations : float
        Number of observations.

    mean : float
        Mean of the portfolio returns.

    annualized_mean : float
        Mean annualized by :math:`mean \times annualization\_factor`

    mean_absolute_deviation : float
        Mean Absolute Deviation. The deviation is the difference between the
        return and a minimum acceptable return (`min_acceptable_return`).

    first_lower_partial_moment : float
        First Lower Partial Moment. The First Lower Partial Moment is the mean of the
        returns below a minimum acceptable return (`min_acceptable_return`).

    variance : float
        Variance (Second Moment)

    annualized_variance : float
        Variance annualized by :math:`variance \times annualization\_factor`

    semi_variance : float
        Semi-variance (Second Lower Partial Moment).
        The semi-variance is the variance of the returns below a minimum acceptable
        return (`min_acceptable_return`).

    annualized_semi_variance : float
        Semi-variance annualized by
        :math:`semi\_variance \times annualization\_factor`

    standard_deviation : float
        Standard Deviation (Square Root of the Second Moment).

    annualized_standard_deviation : float
        Standard Deviation annualized by
        :math:`standard\_deviation \times \sqrt{annualization\_factor}`

    semi_deviation : float
        Semi-deviation (Square Root of the Second Lower Partial Moment).
        The Semi Standard Deviation is the Standard Deviation of the returns below a
        minimum acceptable return (`min_acceptable_return`).

    annualized_semi_deviation : float
        Semi-deviation annualized by
        :math:`semi\_deviation \times \sqrt{annualization\_factor}`

    skew : float
        Skew. The Skew is a measure of the lopsidedness of the distribution.
        A symmetric distribution have a Skew of zero.
        Higher Skew corresponds to longer right tail.

    kurtosis : float
        Kurtosis. It is a measure of the heaviness of the tail of the distribution.
        Higher Kurtosis corresponds to greater extremity of deviations (fat tails).

    fourth_central_moment : float
       Fourth Central Moment.

    fourth_lower_partial_moment : float
        Fourth Lower Partial Moment. It is a measure of the heaviness of the downside
        tail of the returns below a minimum acceptable return (`min_acceptable_return`).
        Higher Fourth Lower Partial Moment corresponds to greater extremity of downside
        deviations (downside fat tail).

    worst_realization : float
        Worst Realization which is the worst return.

    value_at_risk : float
        Historical VaR (Value at Risk).
        The VaR is the maximum loss at a given confidence level (`value_at_risk_beta`).

    cvar : float
        Historical CVaR (Conditional Value at Risk). The CVaR (or Tail VaR) represents
        the mean shortfall at a specified confidence level (`cvar_beta`).

    entropic_risk_measure : float
        Historical Entropic Risk Measure. It is a risk measure which depends on the
        risk aversion defined by the investor (`entropic_risk_measure_theta`) through
        the exponential utility function at a given confidence level
        (`entropic_risk_measure_beta`).

    evar : float
         Historical EVaR (Entropic Value at Risk). It is a coherent risk measure which
         is an upper bound for the VaR and the CVaR, obtained from the Chernoff
         inequality at a given confidence level (`evar_beta`). The EVaR can be
         represented by using the concept of relative entropy.

    drawdown_at_risk : float
        Historical Drawdown at Risk. It is the maximum drawdown at a given
        confidence level (`drawdown_at_risk_beta`).

    cdar : float
        Historical CDaR (Conditional Drawdown at Risk) at a given confidence level
        (`cdar_beta`).

    max_drawdown : float
        Maximum Drawdown.

    average_drawdown : float
        Average Drawdown.

    edar : float
        EDaR (Entropic Drawdown at Risk). It is a coherent risk measure which is an
        upper bound for the Drawdown at Risk and the CDaR, obtained from the Chernoff
        inequality at a given confidence level (`edar_beta`). The EDaR can be
        represented by using the concept of relative entropy.

    ulcer_index : float
        Ulcer Index

    gini_mean_difference : float
        Gini Mean Difference (GMD). It is the expected absolute difference between two
        realizations. The GMD is a superior measure of variability  for non-normal
        distribution than the variance. It can be used to form necessary conditions
        for second-degree stochastic dominance, while the variance cannot.

    mean_absolute_deviation_ratio : float
        Mean Absolute Deviation ratio.
        It is the excess mean (mean - risk_free_rate) divided by the MaD.

    first_lower_partial_moment_ratio : float
        First Lower Partial Moment ratio.
        It is the excess mean (mean - risk_free_rate) divided by the First Lower
        Partial Moment.

    sharpe_ratio : float
        Sharpe ratio.
        It is the excess mean (mean - risk_free_rate) divided by the standard-deviation.

    annualized_sharpe_ratio : float
        Sharpe ratio annualized by
        :math:`sharpe\_ratio \times \sqrt{annualization\_factor}`.

    sortino_ratio : float
        Sortino ratio.
        It is the excess mean (mean - risk_free_rate) divided by the semi
        standard-deviation.

    annualized_sortino_ratio : float
        Sortino ratio annualized by
        :math:`sortino\_ratio \times \sqrt{annualization\_factor}`.

    value_at_risk_ratio : float
        VaR ratio.
        It is the excess mean (mean - risk_free_rate) divided by the Value at Risk
        (VaR).

    cvar_ratio : float
        CVaR ratio.
        It is the excess mean (mean - risk_free_rate) divided by the Conditional Value
        at Risk (CVaR).

    entropic_risk_measure_ratio : float
        Entropic risk measure ratio.
        It is the excess mean (mean - risk_free_rate) divided by the Entropic risk
        measure.

    evar_ratio : float
        EVaR ratio.
        It is the excess mean (mean - risk_free_rate) divided by the EVaR (Entropic
        Value at Risk).

    worst_realization_ratio : float
        Worst Realization ratio.
        It is the excess mean (mean - risk_free_rate) divided by the Worst Realization
        (worst return).

    drawdown_at_risk_ratio : float
        Drawdown at Risk ratio.
        It is the excess mean (mean - risk_free_rate) divided by the drawdown at
        risk.

    cdar_ratio : float
        CDaR ratio.
        It is the excess mean (mean - risk_free_rate) divided by the CDaR (conditional
        drawdown at risk).

    calmar_ratio : float
        Calmar ratio.
        It is the excess mean (mean - risk_free_rate) divided by the Maximum Drawdown.

    average_drawdown_ratio : float
        Average Drawdown ratio.
        It is the excess mean (mean - risk_free_rate) divided by the Average Drawdown.

    edar_ratio : float
        EDaR ratio.
        It is the excess mean (mean - risk_free_rate) divided by the EDaR (Entropic
        Drawdown at Risk).

    ulcer_index_ratio : float
        Ulcer Index ratio.
        It is the excess mean (mean - risk_free_rate) divided by the Ulcer Index.

    gini_mean_difference_ratio : float
        Gini Mean Difference ratio.
        It is the excess mean (mean - risk_free_rate) divided by the Gini Mean
        Difference.
    """

    _read_only_attrs: ClassVar[set] = {
        "returns",
        "observations",
    }

    # Arguments globally used in measures computation
    _measure_global_args: ClassVar[set] = {
        "returns",
        "cumulative_returns",
        "drawdowns",
        "sample_weight",
    } | set(_MEASURE_GLOBAL_PARAMS)

    # Arguments locally used in measures computation
    _measure_local_args: ClassVar[set] = set(_MEASURE_LOCAL_PARAMS)

    # ruff: noqa: RUF023
    __slots__ = {
        # public
        "tag",
        "name",
        # public read-only
        "returns",
        "observations",
        # private
        "_loaded",
        # custom getter and setter
        "_fitness_measures",
        "_annualization_factor",
        "_sample_weight",
        # custom getter (read-only and cached)
        "_fitness",
        "_cumulative_returns",
        "_drawdowns",
        # global args
        "min_acceptable_return",
        "compounded",
        "risk_free_rate",
        # local args
        "value_at_risk_beta",
        "cvar_beta",
        "entropic_risk_measure_theta",
        "entropic_risk_measure_beta",
        "evar_beta",
        "drawdown_at_risk_beta",
        "cdar_beta",
        "edar_beta",
        # measures
        # perf
        "mean",
        # annualized
        "annualized_mean",
        # risk measure
        "mean_absolute_deviation",
        "first_lower_partial_moment",
        "variance",
        "standard_deviation",
        "semi_variance",
        "semi_deviation",
        "fourth_central_moment",
        "fourth_lower_partial_moment",
        "value_at_risk",
        "cvar",
        "entropic_risk_measure",
        "evar",
        "worst_realization",
        "drawdown_at_risk",
        "cdar",
        "max_drawdown",
        "average_drawdown",
        "edar",
        "ulcer_index",
        "gini_mean_difference",
        "skew",
        "kurtosis",
        # annualized
        "annualized_variance",
        "annualized_semi_variance",
        "annualized_standard_deviation",
        "annualized_semi_deviation",
        # ratio
        "mean_absolute_deviation_ratio",
        "first_lower_partial_moment_ratio",
        "sharpe_ratio",
        "sortino_ratio",
        "value_at_risk_ratio",
        "cvar_ratio",
        "entropic_risk_measure_ratio",
        "evar_ratio",
        "worst_realization_ratio",
        "drawdown_at_risk_ratio",
        "cdar_ratio",
        "calmar_ratio",
        "average_drawdown_ratio",
        "edar_ratio",
        "ulcer_index_ratio",
        "gini_mean_difference_ratio",
        # annualized
        "annualized_sharpe_ratio",
        "annualized_sortino_ratio",
    }

    def __init__(
        self,
        returns: FloatArray | list,
        observations: FloatArray | list,
        name: str | None = None,
        tag: str | None = None,
        annualization_factor: float | None = None,
        fitness_measures: list[skt.Measure] | None = None,
        risk_free_rate: float = 0.0,
        compounded: bool = False,
        sample_weight: FloatArray | None = None,
        min_acceptable_return: float | None = None,
        value_at_risk_beta: float = 0.95,
        entropic_risk_measure_theta: float = 1.0,
        entropic_risk_measure_beta: float = 0.95,
        cvar_beta: float = 0.95,
        evar_beta: float = 0.95,
        drawdown_at_risk_beta: float = 0.95,
        cdar_beta: float = 0.95,
        edar_beta: float = 0.95,
        **kwargs: Any,
    ) -> None:
        self._loaded = False
        self._annualization_factor = _resolve_annualization_factor(
            annualization_factor,
            kwargs,
            owner_name=type(self).__name__,
        )
        self.returns = np.asarray(returns)
        self.observations = np.asarray(observations)
        self.sample_weight = sample_weight
        self.risk_free_rate = risk_free_rate
        self.tag = tag
        self.compounded = compounded
        self.min_acceptable_return = min_acceptable_return
        self.value_at_risk_beta = value_at_risk_beta
        self.entropic_risk_measure_theta = entropic_risk_measure_theta
        self.entropic_risk_measure_beta = entropic_risk_measure_beta
        self.cvar_beta = cvar_beta
        self.evar_beta = evar_beta
        self.drawdown_at_risk_beta = drawdown_at_risk_beta
        self.cdar_beta = cdar_beta
        self.edar_beta = edar_beta

        self.name = str(id(self)) if name is None else name
        self._fitness_measures: list[skt.Measure]
        if fitness_measures is None:
            self._fitness_measures = [PerfMeasure.MEAN, RiskMeasure.VARIANCE]
        else:
            self._fitness_measures = fitness_measures
        self._loaded = True

    def __reduce__(self) -> tuple[partial, tuple]:
        # For fast serialization and deserialization
        # We don't want to serialize generic slots but only init arguments.
        # Save them by name so constructor parameter order can change.
        return partial(type(self), **self._get_init_params()), ()

    def _get_init_params(self) -> dict:
        """Return the parameters needed to reconstruct this portfolio."""
        return {
            name: self._sample_weight  # Preserve None for inheritance
            if name == "sample_weight"
            else getattr(self, name)
            for name in args_names(self.__init__)
        }

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, BasePortfolio) and np.array_equal(
            self.fitness, other.fitness
        )

    def __gt__(self, other: BasePortfolio) -> bool:
        if not isinstance(other, BasePortfolio):
            raise TypeError(
                "`>` not supported between instances of `Portfolio` and"
                f" `{type(other)}`"
            )
        return self.dominates(other)

    def __ge__(self, other: BasePortfolio) -> bool:
        if not isinstance(other, BasePortfolio):
            raise TypeError(
                "`>=` not supported between instances of `Portfolio` and"
                f" `{type(other)}`"
            )
        return self.__eq__(other) or self.__gt__(other)

    def __copy__(self) -> Self:
        cls = self.__class__
        result = cls.__new__(cls)
        result._loaded = False
        for attr in self._slots():
            if attr not in _MEASURES_VALUES and attr != "_loaded":
                try:
                    setattr(result, attr, getattr(self, attr))
                except AttributeError:
                    pass
        result._loaded = True
        return result

    def __getattribute__(self, name: str) -> Any:  # noqa: ANN401  # any attribute value
        try:
            return object.__getattribute__(self, name)
        except AttributeError as e:
            # The Measures are the only attributes in __slots__ that are not yet
            # assigned.
            # We assign their values dynamically the first time they are called.
            if name not in _MEASURES_VALUES:
                raise AttributeError(e) from None
            measure = _MEASURES_VALUES[name]
            value = self.get_measure(measure=measure)
            setattr(self, name, value)
            return value

    def __setattr__(self, name: str, value: object) -> None:
        if name != "_loaded" and self._loaded:
            if name in self._read_only_attrs:
                raise AttributeError(
                    f"can't set attribute '{name}' because it is read-only"
                )
            if name in self._measure_global_args or name in self._measure_local_args:
                # When an attribute in GLOBAL_ARGS or LOCAL_ARGS is set, we reset all
                # the measures
                self.clear()
        object.__setattr__(self, name, value)

    def __delattr__(self, name: str) -> None:
        # We only want to raise an error when the attribute doesn't exist and we don't
        # want to raise an error when it's a valid attribute that has not been assigned
        # a value.
        try:
            object.__delattr__(self, name)
        except AttributeError:
            if name not in self._slots():
                raise AttributeError(
                    f"`{type(self).__name__}` object has no attribute '{name}'"
                ) from None

    def __array__(self) -> FloatArray:
        return self.returns

    # Private methods
    def _slots(self) -> set[str]:
        """Return the union of `__slots__` across the class MRO."""
        slots = set()
        for s in self.__class__.__mro__:
            slots.update(getattr(s, "__slots__", set()))
        return slots

    @property
    @abstractmethod
    def composition(self) -> pd.DataFrame:
        """DataFrame of the Portfolio composition."""
        ...

    @abstractmethod
    def contribution(
        self, measure: skt.Measure, spacing: float | None = None, to_df: bool = True
    ) -> FloatArray | list[FloatArray] | pd.DataFrame:
        """Compute the contribution of each asset to a given measure."""
        ...

    # Custom attribute setter and getter
    @property
    def fitness_measures(self) -> list[skt.Measure]:
        """Portfolio fitness measures."""
        return self._fitness_measures

    @fitness_measures.setter
    def fitness_measures(self, value: list[skt.Measure]) -> None:
        """Validate and set the fitness measures and clear the cached fitness."""
        if not isinstance(value, list) or len(value) == 0:
            raise TypeError("`fitness_measures` must be a non-empty list of Measure")
        for val in value:
            if not isinstance(
                val, PerfMeasure | RiskMeasure | ExtraRiskMeasure | RatioMeasure
            ):
                raise TypeError("`fitness_measures` must be a list of Measure")
        self._fitness_measures = value
        delattr(self, "_fitness")

    @property
    def annualization_factor(self) -> float:
        """Portfolio annualization factor."""
        return self._annualization_factor

    @annualization_factor.setter
    def annualization_factor(self, value: float) -> None:
        """Set the annualization factor and clear the measures cache."""
        self._annualization_factor = value
        self.clear()

    # TODO remove deprecated annualized_factor in v2.0
    @property
    def annualized_factor(self) -> float:
        """Deprecated alias for `annualization_factor`."""
        _warn_deprecated_annualized_factor(stacklevel=3)
        return self.annualization_factor

    # TODO remove deprecated annualized_factor in v2.0
    @annualized_factor.setter
    def annualized_factor(self, value: float) -> None:
        """Set the deprecated alias of `annualization_factor` with a warning."""
        _warn_deprecated_annualized_factor(stacklevel=3)
        self.annualization_factor = value

    @property
    def sample_weight(self) -> FloatArray | None:
        """Observations sample weights."""
        return self._sample_weight

    @sample_weight.setter
    def sample_weight(self, value: FloatArray | None) -> None:
        """Validate and set the observations sample weights."""
        if value is not None:
            value = _validate_sample_weight(
                value, n_observations=self.n_observations, ensure_normalized=True
            )
        self._sample_weight = value

    # Custom attribute getter (read-only and cached)
    @cached_property_slots
    def fitness(self) -> FloatArray:
        """Portfolio fitness."""
        res = []
        for measure in self.fitness_measures:
            if isinstance(measure, PerfMeasure | RatioMeasure):
                sign = 1
            else:
                sign = -1
            res.append(sign * getattr(self, str(measure.value)))
        return np.array(res)

    @cached_property_slots
    def cumulative_returns(self) -> FloatArray:
        """Portfolio cumulative returns array.
        Non-compounded (arithmetic) cumulative returns start at 0.
        Compounded (geometric) cumulative returns are expressed as a wealth index,
        starting at 1.0 (i.e., the value of $1 invested).
        """
        return mt.get_cumulative_returns(
            returns=self.returns, compounded=self.compounded, base=1.0
        )

    @cached_property_slots
    def drawdowns(self) -> FloatArray:
        """Portfolio drawdowns array."""
        return mt.get_drawdowns(returns=self.returns, compounded=self.compounded)

    # Classic property
    @property
    def n_observations(self) -> int:
        """Number of observations."""
        return len(self.observations)

    @property
    def returns_df(self) -> pd.Series:
        """Portfolio returns DataFrame."""
        return pd.Series(index=self.observations, data=self.returns, name="returns")

    @property
    def cumulative_returns_df(self) -> pd.Series:
        """Portfolio cumulative returns Series.
        Non-compounded (arithmetic) cumulative returns start at 0.
        Compounded (geometric) cumulative returns are expressed as a wealth index,
        starting at 1.0 (i.e., the value of $1 invested).
        """
        return pd.Series(
            index=self.observations,
            data=self.cumulative_returns,
            name="cumulative_returns",
        )

    @property
    def drawdowns_df(self) -> pd.Series:
        """Portfolio drawdowns Series."""
        return pd.Series(
            index=self.observations,
            data=self.drawdowns,
            name="drawdowns",
        )

    @property
    def measures_df(self) -> pd.DataFrame:
        """DataFrame of all measures."""
        idx = [e.value for enu in [PerfMeasure, RiskMeasure, RatioMeasure] for e in enu]
        res = [getattr(self, attr) for attr in idx]
        return pd.DataFrame(res, index=idx, columns=["measures"])

    # Public methods
    def copy(self) -> Self:
        """Copy the Portfolio attributes without its measures values."""
        return self.__copy__()

    def clear(self) -> None:
        """Clear all measures, fitness, cumulative returns and drawdowns in slots."""
        attrs = ["_fitness", "_cumulative_returns", "_drawdowns"]
        for attr in attrs + list(_MEASURES_VALUES):
            delattr(self, attr)

    def get_measure(self, measure: skt.Measure) -> float:
        """Returns the value of a given measure.

        Parameters
        ----------
        measure : PerfMeasure | RiskMeasure | ExtraRiskMeasure | RatioMeasure
            The input measure.

        Returns
        -------
        value : float
            The measure value.
        """
        if isinstance(measure, PerfMeasure | RiskMeasure | ExtraRiskMeasure):
            # We call the measure functions and their arguments dynamically.
            # The measure functions are called from the "measures" module.
            # The function arguments are retrieved from the class attributes following
            # the below rules:
            # Global measures function arguments (defined in GLOBAL_ARGS) need to be
            # defined in the class attributes with identical name.
            # Local measures function arguments need to be defined in the class
            # attributes with the argument name preceded by the measure name and
            # separated by "_".

            func, args = self._get_measure_func(measure=measure)

            try:
                value = func(**args)
                if measure in [
                    PerfMeasure.ANNUALIZED_MEAN,
                    RiskMeasure.ANNUALIZED_VARIANCE,
                    RiskMeasure.ANNUALIZED_SEMI_VARIANCE,
                ]:
                    value *= self.annualization_factor
                elif measure in [
                    RiskMeasure.ANNUALIZED_STANDARD_DEVIATION,
                    RiskMeasure.ANNUALIZED_SEMI_DEVIATION,
                ]:
                    value *= np.sqrt(self.annualization_factor)
            except Exception as e:
                warnings.warn(
                    f"Unable to calculate the portfolio '{measure.value}' with"
                    f" error: {e}",
                    stacklevel=2,
                )
                value = np.nan
        elif isinstance(measure, RatioMeasure):
            excess_mean = self.mean - self.risk_free_rate
            if measure.is_annualized:
                excess_mean *= self.annualization_factor
            risk = getattr(self, str(measure.linked_risk_measure.value))
            value = excess_mean / risk
        else:
            raise ValueError(f"{measure} is not a Measure.")
        return value

    def dominates(
        self, other: BasePortfolio, idx: slice | IntArray | None = None
    ) -> bool:
        """Portfolio domination.

        Returns true if each objective of the current portfolio fitness is not
        strictly worse than the corresponding objective of the other portfolio fitness
        and at least one objective is strictly better.

        Parameters
        ----------
        other : BasePortfolio
            The other portfolio.

        idx : slice | array, optional
            Indexes or slice indicating on which objectives the domination is performed.
            The default (`None`) is to use all objectives.

        Returns
        -------
        value : bool
            Returns True if the Portfolio dominates the other one.
        """
        if idx is None:
            idx = slice(None)
        return dominate(self.fitness[idx], other.fitness[idx])

    def rolling_measure(
        self,
        measure: skt.Measure = RatioMeasure.SHARPE_RATIO,
        window: int = 30,
        *,
        min_periods: int | None = None,
    ) -> pd.Series:
        """Compute the measure over a rolling window.

        Parameters
        ----------
        measure : Measure, default=RatioMeasure.SHARPE_RATIO
            The measure. The default measure is the Sharpe Ratio.

        window : int, default=30
            The positive window size in observations. The default value is `30`.

        min_periods : int, optional
            Minimum number of non-missing returns required in a window. Must be
            between `1` and `window`. The default (`None`) uses `window`. A smaller
            value evaluates leading partial windows and windows with missing returns.
            Windows containing an infinite return produce NaN.

        Returns
        -------
        series : pandas Series
            The rolling measure Series.

        Notes
        -----
        Windows with fewer than `min_periods` non-missing returns or any infinite
        return produce NaN. Zero-weight observations count toward `min_periods`.
        Sample weights are sliced with the returns and normalized within each
        window by measures that support weighting. Measures without weight support
        retain their unweighted definition. Ratios use the weighted mean in the
        numerator, even when their risk measure is unweighted.
        """
        _validate_positive_integer(window, "window")
        window = int(window)
        if min_periods is None:
            min_periods = window
        _validate_positive_integer(min_periods, "min_periods")
        if min_periods > window:
            raise ValueError(
                "min_periods must be less than or equal to window, "
                f"got min_periods={min_periods!r} and window={window!r}"
            )

        if measure.is_annualized:
            non_annualized_measure = measure.non_annualized_measure
        else:
            non_annualized_measure = measure

        is_ratio = measure.is_ratio
        base_measure = (
            non_annualized_measure.linked_risk_measure  # ty: ignore[unresolved-attribute]
            if is_ratio
            else non_annualized_measure
        )
        # Resolve fixed parameters only. Each window supplies its data and weights.
        measure_func, measure_args = self._get_measure_func(
            measure=base_measure,
            exclude_args=("returns", "drawdowns", "sample_weight"),
        )
        measure_arg_names = args_names(measure_func)
        uses_drawdowns = "drawdowns" in measure_arg_names
        accepts_sample_weight = "sample_weight" in measure_arg_names
        # Ratios use weights for their mean even if the risk measure is unweighted.
        weights = self.sample_weight if accepts_sample_weight or is_ratio else None

        def window_func(
            returns: FloatArray, sample_weight: FloatArray | None = None
        ) -> float:
            """Evaluate the measure on one window."""
            values = (
                mt.get_drawdowns(returns, compounded=self.compounded)
                if uses_drawdowns
                else returns
            )
            if accepts_sample_weight:
                value = measure_func(
                    values, sample_weight=sample_weight, **measure_args
                )
            else:
                value = measure_func(values, **measure_args)
            if not is_ratio:
                return value
            return (
                mt.mean(returns, sample_weight=sample_weight) - self.risk_free_rate
            ) / value

        returns = np.asarray(self.returns, dtype=float)
        if weights is not None:
            weights = np.asarray(weights, dtype=float)

        ends = np.arange(1, len(returns) + 1)
        starts = np.maximum(0, ends - window)
        # Infinite returns invalidate a window regardless of min_periods.
        valid_counts = np.r_[0, np.cumsum(np.isfinite(returns))]
        infinite_counts = np.r_[0, np.cumsum(np.isinf(returns))]
        eligible = (valid_counts[ends] - valid_counts[starts] >= min_periods) & (
            infinite_counts[ends] == infinite_counts[starts]
        )
        values = np.full(len(returns), np.nan)
        for start, end in zip(
            starts[eligible].tolist(), ends[eligible].tolist(), strict=True
        ):
            window_slice = slice(start, end)
            values[end - 1] = window_func(
                returns[window_slice],
                sample_weight=None if weights is None else weights[window_slice],
            )
        rolling = pd.Series(values, index=self.observations)
        if measure.is_annualized:
            if measure in [
                PerfMeasure.ANNUALIZED_MEAN,
                RiskMeasure.ANNUALIZED_VARIANCE,
                RiskMeasure.ANNUALIZED_SEMI_VARIANCE,
            ]:
                rolling *= self.annualization_factor
            elif measure in [
                RiskMeasure.ANNUALIZED_STANDARD_DEVIATION,
                RiskMeasure.ANNUALIZED_SEMI_DEVIATION,
                RatioMeasure.ANNUALIZED_SHARPE_RATIO,
                RatioMeasure.ANNUALIZED_SORTINO_RATIO,
            ]:
                rolling *= np.sqrt(self.annualization_factor)
        return rolling

    def summary(self, formatted: bool = True) -> pd.Series:
        """Portfolio summary of all its measures.

        Parameters
        ----------
        formatted : bool, default=True
            If this is set to True, the measures are formatted into rounded string
            with units.

        Returns
        -------
        summary : pandas Series
            The Portfolio summary.
        """
        measures = (
            e
            for enu in [PerfMeasure, RiskMeasure, ExtraRiskMeasure, RatioMeasure]
            for e in enu
        )
        summary = {}
        for e in measures:
            e: skt.Measure
            try:
                if e.is_ratio:
                    base_measure = e.linked_risk_measure  # ty: ignore[unresolved-attribute]
                else:
                    base_measure = e
                beta = getattr(self, f"{base_measure.value}_beta")
                key = f"{e!s} at {beta:.0%}"
            except AttributeError:
                key = str(e)
            if e.is_ratio or e in [
                RiskMeasure.VARIANCE,
                RiskMeasure.SEMI_VARIANCE,
                ExtraRiskMeasure.ENTROPIC_RISK_MEASURE,
                RiskMeasure.ULCER_INDEX,
            ]:
                percent = False
            else:
                percent = True
            if formatted:
                value = format_measure(getattr(self, str(e.value)), percent=percent)
            else:
                value = getattr(self, str(e.value))
            summary[key] = value
        return pd.Series(summary)

    def plot_cumulative_returns(
        self, log_scale: bool = False, idx: slice | IntArray | None = None
    ) -> go.Figure:
        """Plot the Portfolio cumulative returns.
        Non-compounded (arithmetic) cumulative returns start at 0.
        Compounded (geometric) cumulative returns are expressed as a wealth index,
        starting at 1.0 (i.e., the value of $1 invested).

        Parameters
        ----------
        log_scale : bool, default=False
            If this is set to True, the cumulative returns are displayed with a
            logarithm scale on the y-axis. The cumulative returns must be compounded
            otherwise an exception is raised.

        idx : slice | array, optional
            Indexes or slice of the observations to plot.
            The default (`None`) is to plot all observations.

        Returns
        -------
        plot : Figure
            Returns the plot Figure object.
        """
        if idx is None:
            idx = slice(None)
        df = self.cumulative_returns_df.iloc[idx]
        title = "Cumulative Returns"
        if self.compounded:
            if log_scale:
                title = f"{title} (compounded & log scaled)"
            else:
                title = f"{title} (compounded)"
        else:
            if log_scale:
                raise ValueError(
                    "Plotting with logarithm scaling must be done on cumulative "
                    "returns that are compounded as opposed to non-compounded."
                    "You can change to compounded with `compounded=True`"
                )
            title = f"{title} (non-compounded)"

        fig = df.plot(backend="plotly")
        fig.update_layout(
            title=title,
            xaxis_title="Observations",
            yaxis_title="Cumulative Returns",
            showlegend=False,
        )
        if self.compounded:
            fig.update_yaxes(tickformat=".2f")
        else:
            fig.update_yaxes(tickformat=".2%")
        if log_scale:
            fig.update_yaxes(type="log")
        return fig

    def plot_drawdowns(self, idx: slice | IntArray | None = None) -> go.Figure:
        """Plot the Portfolio drawdowns.

        Parameters
        ----------
        idx : slice | array, optional
            Indexes or slice of the observations to plot.
            The default (`None`) is to plot all observations.

        Returns
        -------
        plot : Figure
            Returns the plot Figure object.
        """
        if idx is None:
            idx = slice(None)
        df = self.drawdowns_df.iloc[idx]
        title = "Drawdowns"
        if self.compounded:
            title = f"{title} (compounded returns)"
        else:
            title = f"{title} (non-compounded returns)"

        fig = df.plot(backend="plotly")
        fig.update_layout(
            title=title,
            xaxis_title="Observations",
            yaxis_title="Drawdowns",
            showlegend=False,
        )
        fig.update_yaxes(tickformat=".1%")
        return fig

    def plot_returns(self, idx: slice | IntArray | None = None) -> go.Figure:
        """Plot the Portfolio returns.

        Parameters
        ----------
        idx : slice | array, optional
            Indexes or slice of the observations to plot.
            The default (`None`) is to plot all observations.

        Returns
        -------
        plot : Figure
            Returns the plot Figure object
        """
        if idx is None:
            idx = slice(None)
        fig = self.returns_df.iloc[idx].plot(backend="plotly")
        fig.update_layout(
            title="Returns",
            xaxis_title="Observations",
            yaxis_title="Returns",
            showlegend=False,
        )
        return fig

    def plot_returns_distribution(
        self, percentile_cutoff: float | None = None
    ) -> go.Figure:
        """Plot the Portfolio returns distribution using Gaussian KDE.

        Parameters
        ----------
        percentile_cutoff : float, default=None
            Percentile cutoff for tail truncation (percentile), in percent.
            If a float p is provided, the distribution support is truncated at the p-th
            and (100 - p)-th percentiles.
            If None, no truncation is applied (uses full min/max of returns).

        Returns
        -------
        plot : Figure
            Returns the plot Figure object
        """
        returns = self.returns
        if percentile_cutoff is None:
            lower, upper = returns.min(), returns.max()
        else:
            lower = np.percentile(returns, percentile_cutoff)
            upper = np.percentile(returns, 100.0 - percentile_cutoff)

        x = np.linspace(lower, upper, 500)
        y = st.gaussian_kde(self.returns, weights=self.sample_weight)(x)

        fig = go.Figure(
            go.Scatter(
                x=x,
                y=y,
                mode="lines",
                fill="tozeroy",
            )
        )

        fig.update_layout(
            title="Returns Distribution",
            xaxis_title="Returns",
            yaxis_title="Probability Density",
            showlegend=False,
        )
        fig.update_xaxes(
            tickformat=".0%",
        )
        return fig

    def plot_rolling_measure(
        self,
        measure: skt.Measure = RatioMeasure.SHARPE_RATIO,
        window: int = 30,
        *,
        min_periods: int | None = None,
    ) -> go.Figure:
        """Plot the measure over a rolling window.

        Parameters
        ----------
        measure : Measure, default = RatioMeasure.SHARPE_RATIO
           The measure.

        window : int, default=30
           The window size.

        min_periods : int, optional
            Minimum number of non-missing returns required in a window. Must be
            between `1` and `window`. The default (`None`) uses `window`. A smaller
            value evaluates leading partial windows and windows with missing returns.
            Windows containing an infinite return produce NaN.

        Returns
        -------
        plot : Figure
            Returns the plot Figure object
        """
        rolling = self.rolling_measure(
            measure=measure, window=window, min_periods=min_periods
        )
        rolling.name = f"{measure} {window} observations"
        fig = rolling.plot(backend="plotly")
        fig.add_hline(
            y=getattr(self, measure.value),
            line_width=1.5,
            line_dash="dash",
            line_color="blue",
        )
        max_val = np.max(rolling)
        min_val = np.min(rolling)
        if max_val > 0 > min_val:
            fig.add_hrect(
                y0=0, y1=max_val * 1.3, line_width=0, fillcolor="green", opacity=0.1
            )
            fig.add_hrect(
                y0=min_val * 1.3, y1=0, line_width=0, fillcolor="red", opacity=0.1
            )

        fig.update_layout(
            title=f"Rolling {measure} - {window} observations window",
            xaxis_title="Observations",
            yaxis_title=str(measure),
            showlegend=False,
        )
        return fig

    def plot_composition(self) -> go.Figure:
        """Plot the Portfolio composition.

        Returns
        -------
        plot : Figure
            Returns the plot Figure object.
        """
        df = self.composition.T
        fig = px.bar(df, x=df.index, y=df.columns)
        fig.update_layout(
            title="Portfolio Composition",
            xaxis_title="Portfolio",
            yaxis_title="Weight",
            legend_title_text="Assets",
        )
        return fig

    def plot_contribution(
        self, measure: skt.Measure, spacing: float | None = None
    ) -> go.Figure:
        r"""Plot the contribution of each asset to a given measure.

        Parameters
        ----------
        measure : Measure
            The measure used for the contribution computation.

        spacing : float, optional
            Spacing "h" of the finite difference:
            :math:`contribution(wi)= \frac{measure(wi-h) - measure(wi+h)}{2h}`

        Returns
        -------
        plot : Figure
            The plotly Figure of assets contribution to the measure.
        """
        df = self.contribution(measure=measure, spacing=spacing, to_df=True).T  # ty: ignore[unresolved-attribute]
        fig = px.bar(df, x=df.index, y=df.columns)
        yaxis = {
            "title": "Contribution",
        }
        if not measure.is_ratio:
            n = optimal_rounding_decimals(df.sum(axis=1).max())
            yaxis["tickformat"] = f",.{n}%"

        fig.update_layout(
            title=f"{measure} Contribution",
            xaxis_title="Portfolio",
            yaxis=yaxis,
            legend_title_text="Assets",
        )
        return fig

    def _get_measure_func(
        self, measure: skt.Measure, *, exclude_args: tuple[str, ...] = ()
    ) -> tuple[FunctionType, dict]:
        """Return the measure function and resolve its non-excluded arguments."""
        if measure.is_annualized:
            func = getattr(mt, str(measure.non_annualized_measure.value))
        else:
            func = getattr(mt, str(measure.value))

        args = {}
        for arg in args_names(func):
            if arg in exclude_args:
                continue
            if arg in self._measure_global_args:
                args[arg] = getattr(self, arg)
            elif arg == "biased":
                args[arg] = False
            else:
                args[arg] = getattr(self, f"{measure.value}_{arg}")
        return func, args


# TODO remove deprecated annualized_factor in v2.0
def _warn_deprecated_annualized_factor(stacklevel: int = 2) -> None:
    """Emit a FutureWarning that `annualized_factor` is deprecated."""
    warnings.warn(
        "`annualized_factor` is deprecated and will be removed in version 2.0. "
        "Use `annualization_factor` instead.",
        FutureWarning,
        stacklevel=stacklevel,
    )


# TODO remove deprecated annualized_factor in v2.0
def _normalize_annualization_factor_alias(params: dict, *, stacklevel: int = 2) -> dict:
    """Normalize the deprecated `annualized_factor` key in a parameters dictionary."""
    params = params.copy()
    if "annualized_factor" not in params:
        return params

    annualized_factor = params.pop("annualized_factor")
    annualization_factor = params.get("annualization_factor")
    if annualization_factor is not None and annualized_factor is not None:
        raise ValueError(
            "`annualized_factor` is deprecated; pass only `annualization_factor`."
        )
    if annualized_factor is not None:
        _warn_deprecated_annualized_factor(stacklevel=stacklevel)
        params["annualization_factor"] = annualized_factor
    elif "annualization_factor" not in params:
        # Preserve an explicit deprecated `None` so it can override a value from a
        # lower-precedence parameter source and resolve to the constructor default.
        params["annualization_factor"] = None
    return params


def _resolve_annualization_factor(
    annualization_factor: float | None,
    kwargs: dict,
    *,
    owner_name: str,
) -> float:
    """Resolve the annualization factor from the current and deprecated arguments."""
    params = {"annualization_factor": annualization_factor}
    if "annualized_factor" in kwargs:
        params["annualized_factor"] = kwargs.pop("annualized_factor")
    if len(kwargs) != 0:
        key = next(iter(kwargs))
        raise TypeError(
            f"{owner_name}.__init__() got an unexpected keyword argument '{key}'"
        )
    annualization_factor = _normalize_annualization_factor_alias(params, stacklevel=6)[
        "annualization_factor"
    ]
    if annualization_factor is None:
        return _ANNUALIZATION_FACTOR_DEFAULT
    return annualization_factor
