"""Datasets module."""

# Copyright (c) 2023-2026
# Author: Hugo Delatte <hugo.delatte@skfoliolabs.com>
# SPDX-License-Identifier: BSD-3-Clause

from skfolio.datasets._base import (
    load_factors_dataset,
    load_ftse100_dataset,
    load_nasdaq_dataset,
    load_sp500_dataset,
    load_sp500_implied_vol_dataset,
    load_sp500_index,
)
from skfolio.datasets._synthetic import make_synthetic_characteristics

__all__ = [
    "load_factors_dataset",
    "load_ftse100_dataset",
    "load_nasdaq_dataset",
    "load_sp500_dataset",
    "load_sp500_implied_vol_dataset",
    "load_sp500_index",
    "make_synthetic_characteristics",
]
