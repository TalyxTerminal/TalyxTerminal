"""Base classes and shared helpers for factor-model alpha estimators."""

# Copyright (c) 2023-2026
# Author: Hugo Delatte <hugo.delatte@skfoliolabs.com>
# SPDX-License-Identifier: BSD-3-Clause

from __future__ import annotations

from abc import ABC, abstractmethod
from enum import auto
from typing import Any, Literal

import numpy as np
import sklearn as sk
import sklearn.base as skb
import sklearn.utils as sku
from sklearn.utils import parallel as skp

from skfolio import typing as skt
from skfolio._constants import _DESCRIPTOR_SCORES, _EXPOSURES, _PASSTHROUGH
from skfolio.containers import (
    AssetPanel,
    AssetPanelView,
    Field3D,
    InactivePolicy,
    concat,
)
from skfolio.descriptor import BaseDescriptor
from skfolio.descriptor._base import BaseDescriptorComposition
from skfolio.linear_model._cross_sectional._utils import _cs_neutralize
from skfolio.preprocessing import BaseCSTransformer, CSStandardScaler, CSWinsorizer
from skfolio.typing import FloatArray, ObjArray, StrArray
from skfolio.utils._factor_tools import _expand_factor_names, _factor_name_maps
from skfolio.utils.tools import (
    AutoEnum,
    _validate_positive_integer,
    call_asset_panel_transform,
    check_estimator,
)

__all__ = [
    "BaseAlpha",
    "BaseAlphaDescriptorComposition",
    "ForecastUnit",
]


class ForecastUnit(AutoEnum):
    """Unit of the intermediate alpha forecast."""

    IDIO_RETURN = auto()
    IDIO_SHARPE = auto()


class BaseAlpha(skb.BaseEstimator, ABC):
    """Base class for all Alpha estimators in skfolio."""

    alpha_: FloatArray | None
    n_assets_: int
    asset_names_: ObjArray

    @abstractmethod
    def fit(self, X: AssetPanel, y: None = None, **fit_params: Any) -> BaseAlpha:
        """Fit the alpha estimator and store the latest alpha forecast in `alpha_`.

        Parameters
        ----------
        X : AssetPanel
            Input panel data.

        y : None
            Ignored. Present for compatibility with scikit-learn's API.

        **fit_params : dict
            Additional fit parameters passed to the sub-estimators.

        Returns
        -------
        self : BaseAlpha
            Fitted estimator.
        """
        ...


class BaseAlphaDescriptorComposition(BaseDescriptorComposition, ABC):
    """Base class for alpha estimators built from composing descriptor estimators."""

    descriptors: list[tuple[str, BaseDescriptor]]
    horizon: int
    signal_lag: int
    neutralize_against: list[str] | None
    outlier_transformer: skt.CSTransformer
    scoring_transformer: skt.CSTransformer
    transform_by_group: str | None
    forecast_unit: ForecastUnit
    n_jobs: int

    descriptors_: list[BaseDescriptor]
    named_descriptors_: dict[str, BaseDescriptor]
    outlier_transformer_: BaseCSTransformer | Literal["passthrough"]
    scoring_transformer_: BaseCSTransformer | Literal["passthrough"]

    def _validate_descriptor_params(self) -> None:
        """Validate common descriptor composition hyperparameters."""
        if not self.descriptors:
            raise ValueError("descriptors cannot be empty")
        if not isinstance(self.forecast_unit, ForecastUnit):
            raise TypeError("forecast_unit must be of type `ForecastUnit`")

    def _validate_common_params(self) -> None:
        """Validate common descriptor-alpha hyperparameters with target timing."""
        self._validate_descriptor_params()
        _validate_positive_integer(self.horizon, "horizon")
        _validate_positive_integer(self.signal_lag, "signal_lag")

    def _initialize_common_state(self) -> None:
        """Initialize common descriptor state and cross-sectional transformers."""
        names, descriptors = self._validate_descriptors()

        self.descriptors_ = [sk.clone(des) for des in descriptors]
        self.named_descriptors_ = {
            name: estimator
            for name, estimator in zip(names, self.descriptors_, strict=True)
        }

        self.outlier_transformer_ = check_estimator(
            self.outlier_transformer,
            default=CSWinsorizer(),
            check_type=BaseCSTransformer,
        )

        self.scoring_transformer_ = check_estimator(
            self.scoring_transformer,
            default=CSStandardScaler(),
            check_type=BaseCSTransformer,
        )

    def _compute_scores(
        self, X: AssetPanel, method: str, routed_params: sku.Bunch
    ) -> FloatArray:
        """Compute transformed descriptor scores from the input panel."""
        cs_weights = X.estimation_mask.astype(float)
        cs_groups = (
            X[self.transform_by_group] if self.transform_by_group is not None else None
        )

        # Threading avoids copying the (potentially large) AssetPanel to each worker.
        # Workers only read from it, so shared memory is safe. Descriptor computations
        # are NumPy-dominated and release the GIL, giving true parallelism with threads.
        scores = skp.Parallel(n_jobs=self.n_jobs, prefer="threads")(
            skp.delayed(call_asset_panel_transform)(
                descriptor,
                X=X,
                fit_params=routed_params[name][method],
                method=f"{method}_transform",
            )
            for name, descriptor in self.named_descriptors_.items()
        )

        for i, score in enumerate(scores):
            if self.outlier_transformer_ != _PASSTHROUGH:
                score = self.outlier_transformer_.fit_transform(
                    score, cs_weights=cs_weights, cs_groups=cs_groups
                )
            if self.scoring_transformer_ != _PASSTHROUGH:
                score = self.scoring_transformer_.fit_transform(
                    score, cs_weights=cs_weights, cs_groups=cs_groups
                )
            scores[i] = score

        scores = np.stack(scores, axis=2)

        # Score neutralization
        if self.neutralize_against is not None:
            field = X.fields[_EXPOSURES]
            if not isinstance(field, Field3D):
                raise TypeError(
                    f'Field "{_EXPOSURES}" must be a Field3D to neutralize scores, '
                    f"got {type(field).__name__}."
                )
            scores = _neutralize_scores(
                neutralize_against=self.neutralize_against,
                scores=scores,
                exposures=field.values,
                cs_weights=cs_weights,
                factor_names=field.third_axis_labels,
                factor_families=field.third_axis_groups,
            )
            # Re-apply scoring after neutralization
            if self.scoring_transformer_ != _PASSTHROUGH:
                for i in range(len(self.descriptors_)):
                    scores[:, :, i] = self.scoring_transformer_.fit_transform(
                        scores[:, :, i], cs_weights=cs_weights, cs_groups=cs_groups
                    )

        return scores

    def _make_training_panel(
        self,
        X: AssetPanel | AssetPanelView,
        *,
        scores: FloatArray,
        fields: list[str],
    ) -> AssetPanel:
        """Build the compact panel used for online target maturation."""
        panel = (
            X.to_panel(fields=fields, deep=False)
            if isinstance(X, AssetPanelView)
            else X.sel(fields=fields)
        )
        panel[_DESCRIPTOR_SCORES] = Field3D(
            scores,
            third_axis_name="descriptor",
            third_axis_labels=list(self.named_descriptors_),  # ty: ignore[invalid-argument-type]
            inactive_policy=InactivePolicy.IGNORE,
        )
        return panel  # ty: ignore[invalid-return-type]

    def _prepend_buffer(self, current: AssetPanel) -> AssetPanel:
        """Prepend pending rows to the current compact training panel."""
        if self._buffer is None:
            return current
        return concat([self._buffer, current])

    def _update_buffers(self, combined: AssetPanel) -> None:
        """Keep only rows needed to mature future forward-return targets."""
        buffer_start = max(0, combined.n_observations - self._target_gap)
        self._buffer = combined[buffer_start:].to_panel(deep=True)

    def _initialize_buffers(self) -> None:
        """Initialize online buffers."""
        self._buffer = None

    @property
    def _target_gap(self) -> int:
        """Number of future rows required before a signal observation matures."""
        return self.signal_lag + self.horizon - 1


def _neutralize_scores(
    neutralize_against: list[str],
    scores: FloatArray,
    exposures: FloatArray,
    cs_weights: FloatArray,
    factor_names: StrArray,
    factor_families: StrArray | None = None,
) -> FloatArray:
    """Neutralize descriptor scores against selected factor exposures.

    Parameters
    ----------
    neutralize_against : list of str
        Factor names or family names to neutralize each descriptor score against.

    scores : ndarray of shape (n_observations, n_assets, n_descriptors)
        Descriptor score panels. The array is modified in-place.

    exposures : ndarray of shape (n_observations, n_assets, n_factors)
        Factor exposures used as neutralization variables.

    cs_weights : ndarray of shape (n_observations, n_assets)
        Cross-sectional weights for the neutralization regressions.

    factor_names : ndarray of shape (n_factors,)
        Factor names.

    factor_families : ndarray of shape (n_factors,), optional
        Family label for each factor. If provided, `neutralize_against` may contain
        family names.

    Returns
    -------
    scores : ndarray of shape (n_observations, n_assets, n_descriptors)
        The input score array with each descriptor replaced by its neutralized residuals.

    Raises
    ------
    ValueError
        If a neutralization target is neither a factor name nor a family name.
    """
    factor_to_idx, family_to_idx = _factor_name_maps(factor_names, factor_families)
    targets_idx = _expand_factor_names(neutralize_against, factor_to_idx, family_to_idx)
    if len(targets_idx) == 0:
        return scores

    x = exposures[:, :, targets_idx]
    for i in range(scores.shape[2]):
        scores[:, :, i], _ = _cs_neutralize(
            y=scores[:, :, i], x=x, cs_weights=cs_weights
        )

    return scores
