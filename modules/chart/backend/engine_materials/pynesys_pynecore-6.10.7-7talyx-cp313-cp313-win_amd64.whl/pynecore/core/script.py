from typing import Any, Callable, TypeVar, overload
import os
import sys

from dataclasses import dataclass, field, fields
from enum import StrEnum
from pathlib import Path

import pynecore.lib.format as _format
import pynecore.lib.scale as _scale
import pynecore.lib.strategy as _strategy
import pynecore.lib.currency as _currency
import pynecore.lib.display as _display

from pynecore.core.broker.models import ScriptRequirements

from pynecore.types import script_type as _script_type
from pynecore.types.color import Color
from pynecore.types import PyneFloat, PyneInt
from pynecore.types.pine_types import pine_int
from pynecore.types.na import na_int

__all__ = ['script', 'input']

from pynecore.types.source import Source
from . import safe_convert

# Global registry for library main functions
_registered_libraries: list[tuple[str, Callable]] = []

# TypeVar for enum type preservation
TEnum = TypeVar('TEnum', bound=StrEnum)
# The generic input() is typed by its default value
TInput = TypeVar('TInput')

# MEASURED on TradingView: ``commission_type`` accepts the undocumented value ``"cash"``
# (reachable by passing ``strategy.cash``, which is a QtyType constant of the same string).
# TradingView's argument validator rejects every other out-of-list value at compile time --
# a literal ``"cash"`` included -- but a built-in constant identifier bypasses it, and the
# broker emulator then charges ``commission_value`` as a FLAT FEE PER ORDER (probe:
# size 7, value 30 -> trade commission 60).
_COMMISSION_TYPE_ALIASES: dict[str, Any] = {
    _strategy.cash: _strategy.commission.cash_per_order,
}


@dataclass(kw_only=True, slots=True)
class InputData:
    """
    Input dataclass
    """
    id: str | None = None
    input_type: str | None = None
    defval: int | bool | Color | float | str | None = None
    title: str | None = None
    minval: int | float | None = None
    maxval: int | float | None = None
    step: int | float | None = None
    tooltip: str | None = None
    inline: str | None = None
    group: str | None = None
    confirm: bool | None = False
    options: tuple[int | float | str, ...] | None = None
    display: _display.Display | None = None


_old_input_values: dict[str, Any] = {}
_programmatic_inputs: dict[str, Any] = {}
#: Script settings (``[script]`` toml fields) to apply over the toml, like ``_programmatic_inputs``
_programmatic_settings: dict[str, Any] = {}
#: Whether the toml the decorator saves records the programmatic overrides too
_save_programmatic_overrides: bool = False
inputs: dict[str, InputData] = {}


# noinspection PyShadowingBuiltins,PyShadowingNames,PyDunderSlots,PyUnresolvedReferences
@dataclass(kw_only=True, slots=True)
class Script:
    """
    Script parameters dataclass
    """
    # These fields will be skipped when saving to toml
    _SKIP_FIELDS = {'script_type', 'inputs', 'title', 'shorttitle', 'position', 'na_bool',
                    'close_by_id'}

    script_type: _script_type.ScriptType | None = None
    inputs: dict[str, InputData] = field(default_factory=dict)
    #: The script keeps Pine v4/v5's three-state bool (``bool b = na`` is a real na)
    na_bool: bool = False
    #: Same-bar ``strategy.close()`` orders share one order slot per entry id (Pine v4/v5)
    close_by_id: bool = False

    title: str | None = None
    shorttitle: str | None = None

    overlay: bool = False
    format: _format.Format = _format.inherit
    precision: int | None = None
    scale: _scale.Scale | None = None
    pyramiding: int = 1
    calc_on_order_fills: bool = False
    calc_on_every_tick: bool = False
    calc_on_every_history_tick: bool = False
    max_bars_back: int = 0
    timeframe: str | None = None
    timeframe_gaps: bool = True
    explicit_plot_zorder: bool = False
    max_lines_count: int = 50
    max_labels_count: int = 50
    max_boxes_count: int = 50
    calc_bars_count: int = 0
    max_polylines_count: int = 50
    dynamic_requests: bool = False
    behind_chart: bool = True

    backtest_fill_limits_assumption: int = 0
    default_qty_type: _strategy.QtyType = _strategy.percent_of_equity
    default_qty_value: float = 100
    initial_capital: float | int = 100000
    currency: _currency.Currency = _currency.NONE
    slippage: int = 0
    commission_type: _strategy.commission.Commission = _strategy.commission.percent  # type: ignore
    commission_value: int | float = 0.0
    process_orders_on_close: bool = False
    close_entries_rule: str = 'FIFO'
    margin_long: int | float = 100.0  # Defaulted to 100.0 in Pine Script v6
    margin_short: int | float = 100.0  # Defaulted to 100.0 in Pine Script v6
    risk_free_rate: float = 2.0
    use_bar_magnifier: bool = True
    fill_orders_on_standard_ohlc: bool = False

    position: _strategy.PositionBase = None  # type: ignore[assignment]

    _broker_requirements: ScriptRequirements | None = None

    _modified: set[str] = field(default_factory=set)
    #: The settings the script itself declares (decorator arguments), before any toml override
    _defaults: dict[str, Any] = field(default_factory=dict)

    def settable_fields(self) -> list[str]:
        """
        Names of the settings a ``[script]`` toml section may override.

        :return: Field names in declaration order
        """
        return [f.name for f in fields(self)
                if not f.name.startswith('_') and f.name not in self._SKIP_FIELDS]

    def default(self, key: str) -> Any:
        """
        The value the script itself declares for a setting, ignoring any toml override.

        :param key: The setting name
        :return: The declared value
        """
        return self._defaults[key] if key in self._defaults else getattr(self, key)

    def set_setting(self, key: str, value: Any) -> None:
        """
        Override a setting. A value equal to the script's own declaration is no override:
        it is not marked modified, so ``save()`` writes it commented out.

        :param key: The setting name, one of ``settable_fields()``
        :param value: The new value
        """
        if key not in self.settable_fields():
            raise ValueError(f"Not a settable script field: {key}")
        if key == 'commission_type':
            value = _COMMISSION_TYPE_ALIASES.get(value, value)
        elif key == 'pyramiding':
            # Pyramiding must be at least 1
            value = max(value, 1)
        setattr(self, key, value)
        if value == self.default(key):
            self._modified.discard(key)
        else:
            self._modified.add(key)

    def save(self, path: Path):
        """
        Save script settings to TOML-like format.
        Non-settable fields are commented out with '#'.
        None values are also commented out.
        Input values are saved with their metadata as comments.

        :param path: Path to save the file
        """

        def _format_value(value) -> str:
            """Format value according to its type"""
            if isinstance(value, bool):
                return str(value).lower()
            if isinstance(value, (int, float)):
                return str(value)
            if isinstance(value, Color):
                value = str(value)
            if isinstance(value, str):
                # Escape newlines and backslashes for valid TOML
                escaped = value.replace('\\', '\\\\').replace('\n', '\\n').replace('\r', '\\r')
                return f'"{escaped}"'
            return str(value)

        lines = [
            "# Indicator / Strategy / Library Settings",
            "",
            "[script]"
        ]

        # Save general settings
        for key in self.settable_fields():
            value = getattr(self, key)
            if value is None:
                line = f"#{key} ="
            else:
                line = "#" if key not in self._modified else ""
                line += f"{key} = {_format_value(value)}"
            lines.append(line)

        # Add an empty line before inputs
        lines.append("")
        lines.append("# Input Settings")

        # Save inputs
        for arg_name, input_data in self.inputs.items():
            if not arg_name:
                continue
            lines.append(f"\n[inputs.{arg_name.removesuffix('__global__')}]")
            lines.append("# Input metadata, cannot be modified")

            # Add all metadata as comments
            from dataclasses import fields as input_fields
            for field in input_fields(input_data):
                key = field.name
                value = getattr(input_data, key)
                if key == 'id':
                    continue
                if value is not None:
                    # We use ':` to not confuse with real values
                    lines.append(f"# {key.rjust(10)}: {_format_value(value)}")

            lines.append("# Change here to modify the input value")

            # Add the actual value
            if input_data.defval is not None and arg_name in _old_input_values:
                lines.append(f"value = {_format_value(_old_input_values[arg_name])}")
            else:
                lines.append("#value =")

        # Write to file
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')

    def load(self, path: str | Path) -> None:
        """
        Load script settings from TOML file and update this script instance.
        Only loads settable fields and input values, preserving the original script structure.

        :param path: Path to load the file from
        """
        import tomllib

        with open(path, 'rb') as f:
            data = tomllib.load(f)

        if 'script' not in data:
            raise ValueError("Invalid TOML: missing [script] section!")

        script_data = data['script']

        settable = self.settable_fields()
        for key, value in script_data.items():
            if key in settable:
                self.set_setting(key, value)

        if 'inputs' not in data:
            return

        # Fill old_input_values
        for arg_name, arg_data in data['inputs'].items():
            if 'value' not in arg_data:
                continue
            _old_input_values[arg_name] = arg_data['value']
            _old_input_values[arg_name + '__global__'] = arg_data['value']  # For strict mode

    #
    # decorators
    #

    def _decorate(self):
        # Get the script path from the caller frame
        script_path = Path(sys._getframe(2).f_globals['__file__']).resolve()  # noqa F821
        toml_path = script_path.with_suffix('.toml')

        # Pyramiding must be at least 1
        if self.pyramiding <= 0:
            self.pyramiding = 1
        self._defaults = {key: getattr(self, key) for key in self.settable_fields()}

        # Load settings from toml file if exists
        if toml_path.exists():
            self.load(toml_path)

        # The programmatic overrides belong to the script being run. A library it imports
        # is decorated first, so it must leave them for that script.
        is_runnable = self.script_type in (_script_type.indicator, _script_type.strategy)
        save_overrides = _save_programmatic_overrides
        toml_input_values = dict(_old_input_values)

        # Programmatic settings (override .toml values), applied once the toml is saved
        settings: dict[str, Any] = {}
        if is_runnable:
            settings = dict(_programmatic_settings)
            _programmatic_settings.clear()

        # Apply programmatic inputs (override .toml values)
        input_overrides: set[str] = set()
        if is_runnable and _programmatic_inputs:
            input_overrides = set(_programmatic_inputs)
            for key, value in _programmatic_inputs.items():
                _old_input_values[key] = value
                _old_input_values[key + '__global__'] = value
            _programmatic_inputs.clear()

        def decorator(func):
            # Save inputs to script instance then clear inputs (for next script)
            self.inputs = inputs.copy()  # type: ignore
            inputs.clear()

            # Set script attribute to the main function to be able to access script properties
            setattr(func, 'script', self)

            if is_runnable:
                # The inputs are only known once the defaults of main() have run. Strict
                # compilation suffixes the input ids with ``__global__``; an override is
                # keyed by the plain name, the way the toml spells it.
                input_names = {key.removesuffix('__global__') for key in self.inputs}
                unknown = input_overrides - input_names - self.inputs.keys()
                if unknown:
                    raise ValueError(
                        f"Unknown input(s): {', '.join(sorted(unknown))}. Inputs are keyed by "
                        f"the main() parameter name: {', '.join(sorted(input_names)) or 'none'}")

                # Save toml file if not in pytest and not disabled by env var PYNE_SAVE_SCRIPT_TOML = 0
                save = os.environ.get('PYNE_SAVE_SCRIPT_TOML', '1') == '1' and 'pytest' not in sys.modules
                if save and not save_overrides:
                    # The overrides only configure this run: the toml keeps what it held
                    _old_input_values.clear()
                    _old_input_values.update(toml_input_values)
                    self.save(toml_path)
                for key, value in settings.items():
                    self.set_setting(key, value)
                if save and save_overrides:
                    self.save(toml_path)

                # Publish the script timeframe while the module body is still running:
                # the security transformer appends ``__security_contexts__`` AFTER this
                # decorator, and it evaluates ``timeframe.period`` at module level. In a
                # script running on a higher timeframe that must already resolve to the
                # SCRIPT's timeframe -- which is what turns
                # ``request.security(syminfo.tickerid, timeframe.period, x)`` into the
                # same-context no-op TradingView makes of it.
                # Local import: ``pynecore.lib`` imports this module at its own
                # module level, so a top-level import here is a cycle.
                from pynecore import lib as _lib
                _lib._script_timeframe = self.timeframe

            _old_input_values.clear()
            return func

        return decorator

    # noinspection DuplicatedCode
    @classmethod
    def indicator(
            cls,
            title='', shorttitle='',
            overlay=False,
            format: _format.Format = _format.inherit,
            precision: int | None = None,
            scale: _scale.Scale | None = None,
            max_bars_back=0,
            timeframe: str | None = None,
            timeframe_gaps=True,
            explicit_plot_zorder=False,
            max_lines_count=50,
            max_labels_count=50,
            max_boxes_count=50,
            calc_bars_count=0,
            max_polylines_count=50,
            dynamic_requests=False,
            behind_chart=True,
            na_bool=False,
            *_, **__
    ) -> Callable[..., Any]:
        """
        Decorator for indicator script. You should deocrate `main` function with this decorator if
        your script is an indicator script.

        :param title: The title of the script
        :param shorttitle: The script's display name
        :param overlay: If True, the script will be displayed on the price chart as an overlay,
                        otherwise it will be displayed in a separate pane
        :param format: Specifies the formatting of the script's displayed values
        :param precision: Specifies the number of digits after the floating point of the script's displayed values
        :param scale: The price scale used
        :param max_bars_back: The length of the historical buffer the script keeps for every
                              Series variables which determines how many past values can be
                              referenced by Series objects
        :param timeframe: Adds multi-timeframe functionality to simple scripts
        :param timeframe_gaps: Specifies how the indicator's values are displayed on chart bars
                               when the `timeframe` is higher than the chart's timeframe.
        :param explicit_plot_zorder: Specifies the order in which the script's plots, fills, and hlines are rendered
        :param max_lines_count: The number of last line drawings displayed on the chart
        :param max_labels_count: The number of last label drawings displayed
        :param max_boxes_count: The number of last box drawings displayed
        :param calc_bars_count: Limits the initial calculation of a script to the last number of bars specified
        :param max_polylines_count: The number of last polyline drawings displayed
        :param dynamic_requests: Specifies whether the script can dynamically call functions from
                                 the `request.*()` namespace
        :param behind_chart: Controls whether the script's plots and drawings in the main chart pane
                             appear behind the chart display
        :param na_bool: Keep Pine v4/v5's three-state bool: a bool may be na (a history
                        before warm-up, ``na(bool)``, a fresh array or UDT bool); v6 has
                        no such state
        """
        script = cls()
        script.script_type = _script_type.indicator
        script.title = title
        script.shorttitle = shorttitle

        script.overlay = overlay
        script.format = format
        script.precision = precision
        script.scale = scale
        script.max_bars_back = max_bars_back
        script.timeframe = timeframe
        script.timeframe_gaps = timeframe_gaps
        script.explicit_plot_zorder = explicit_plot_zorder
        script.max_lines_count = max_lines_count
        script.max_labels_count = max_labels_count
        script.max_boxes_count = max_boxes_count
        script.calc_bars_count = calc_bars_count
        script.max_polylines_count = max_polylines_count
        script.dynamic_requests = dynamic_requests
        script.behind_chart = behind_chart

        script.na_bool = na_bool
        return script._decorate()

    # noinspection DuplicatedCode
    @classmethod
    def strategy(
            cls,
            title='', shorttitle='',
            overlay=False,
            format: _format.Format = _format.inherit,
            precision: int | None = None,
            scale: _scale.Scale | None = None,

            pyramiding: int = 0,
            calc_on_order_fills=False,
            calc_on_every_tick=False,
            calc_on_every_history_tick=False,

            max_bars_back=0,

            backtest_fill_limits_assumption=0,
            default_qty_type: _strategy.QtyType = _strategy.percent_of_equity,
            default_qty_value: float = 100,
            initial_capital: float | int = 100000,
            currency: _currency.Currency = _currency.NONE,
            slippage: int = 0,
            commission_type: _strategy.commission.Commission = _strategy.commission.percent,  # type: ignore
            commission_value: int | float = 0.0,
            process_orders_on_close=False,
            close_entries_rule='FIFO',
            margin_long: int | float = 100.0,
            margin_short: int | float = 100.0,

            explicit_plot_zorder=False,
            max_lines_count=50,
            max_labels_count=50,
            max_boxes_count=50,
            calc_bars_count=0,

            risk_free_rate=2.0,
            use_bar_magnifier=True,
            fill_orders_on_standard_ohlc=False,

            max_polylines_count=50,
            dynamic_requests=False,

            behind_chart=True,

            _broker_requirements: ScriptRequirements | None = None,

            na_bool=False,
            close_by_id=False,
            *_, **__
    ) -> Callable[..., Any]:
        """
        Decorator for strategy script. You should deocrate `main` function with this decorator if
        your script is a strategy script.

        :param title: The title of the script
        :param shorttitle: The script's display name
        :param overlay: If True, the script will be displayed on the price chart as an overlay,
        :param format: Specifies the formatting of the script's displayed values
        :param precision: Specifies the number of digits after the floating point of the script's displayed values
        :param scale: The price scale used
        :param pyramiding: The maximum number of entries allowed in the same direction
        :param calc_on_order_fills: Specifies whether the strategy should be recalculated after an order is filled
        :param calc_on_every_tick: Specifies whether the strategy should be recalculated on each realtime tick
        :param calc_on_every_history_tick: Specifies whether the strategy should be recalculated on every
                                          available tick of a historical bar instead of once at its close
        :param max_bars_back: The length of the historical buffer the script keeps for every
        :param backtest_fill_limits_assumption: Limit order execution threshold in ticks
        :param default_qty_type: Specifies the units used for `default_qty_value`
        :param default_qty_value: The default quantity to trade, in units determined by the argument
                                 used with the `default_qty_type` parameter
        :param initial_capital: The amount of funds initially available for the strategy to trade,
                                in units of `currency`
        :param currency: Currency used by the strategy in currency-related calculations
        :param slippage: Slippage expressed in ticks
        :param commission_type: Determines what the number passed to the `commission_value`
        :param commission_value: Commission applied to the strategy's orders in units determined by
                                 the argument passed to the `commission_type` parameter
        :param process_orders_on_close: When set to true, generates an additional attempt to execute
                                        orders after a bar closes and strategy calculations are completed.
        :param close_entries_rule: Determines the order in which trades are closed
        :param margin_long: Margin long is the percentage of the purchase price of a security that
                            must be covered by cash or collateral for long positions
        :param margin_short: Margin short is the percentage of the purchase price of a security that
                             must be covered by cash or collateral for short positions
        :param explicit_plot_zorder: Specifies the order in which the script's plots, fills, and hlines are rendered
        :param max_lines_count: The number of last line drawings displayed on the chart
        :param max_labels_count: The number of last label drawings displayed
        :param max_boxes_count: The number of last box drawings displayed
        :param calc_bars_count: Limits the initial calculation of a script to the last number of bars specified
        :param risk_free_rate: The risk-free rate of return is the annual percentage change in the
                               value of an investment with minimal or zero risk
        :param use_bar_magnifier: When true, the Broker Emulator uses lower timeframe data during
                                  history backtesting to achieve more realistic results
        :param fill_orders_on_standard_ohlc: When true, forces strategies running on Heikin Ashi
                                             charts to fill orders using actual OHLC prices, for more
                                             realistic results.
        :param max_polylines_count: The number of last polyline drawings displayed
        :param dynamic_requests: Specifies whether the script can dynamically call functions from
        :param behind_chart: Controls whether the script's plots and drawings in the main chart pane
        :param na_bool: Keep Pine v4/v5's three-state bool: a bool may be na (a history
                        before warm-up, ``na(bool)``, a fresh array or UDT bool); v6 has
                        no such state
        :param close_by_id: Keep Pine v4/v5's ``strategy.close()`` order slots: every close
                            of one entry id on a bar modifies the same pending order, so the
                            last call wins; v6 gives every close statement its own slot
        :param _broker_requirements: Broker capability requirements of the script, internal use only
        """
        script = cls()
        script.script_type = _script_type.strategy
        script.title = title
        script.shorttitle = shorttitle

        script.overlay = overlay
        script.format = format
        script.precision = precision
        script.scale = scale

        script.pyramiding = pyramiding
        script.calc_on_order_fills = calc_on_order_fills
        script.calc_on_every_tick = calc_on_every_tick
        script.calc_on_every_history_tick = calc_on_every_history_tick

        script.max_bars_back = max_bars_back

        script.backtest_fill_limits_assumption = backtest_fill_limits_assumption
        script.default_qty_type = default_qty_type
        script.default_qty_value = default_qty_value
        script.initial_capital = initial_capital
        script.currency = currency
        script.slippage = slippage
        script.commission_type = _COMMISSION_TYPE_ALIASES.get(commission_type, commission_type)
        script.commission_value = commission_value
        script.process_orders_on_close = process_orders_on_close
        script.close_entries_rule = close_entries_rule
        script.margin_long = margin_long
        script.margin_short = margin_short
        script.explicit_plot_zorder = explicit_plot_zorder

        script.max_lines_count = max_lines_count
        script.max_labels_count = max_labels_count
        script.max_boxes_count = max_boxes_count
        script.calc_bars_count = calc_bars_count

        script.risk_free_rate = risk_free_rate
        script.use_bar_magnifier = use_bar_magnifier
        script.fill_orders_on_standard_ohlc = fill_orders_on_standard_ohlc

        script.max_polylines_count = max_polylines_count
        script.dynamic_requests = dynamic_requests
        script.behind_chart = behind_chart

        script.position = _strategy.SimPosition()

        script._broker_requirements = _broker_requirements

        script.na_bool = na_bool
        script.close_by_id = close_by_id
        return script._decorate()

    @classmethod
    def library(
            cls,
            title='',
            overlay=False,
            dynamic_requests=False,
            na_bool=False,
            *_, **__
    ) -> Callable[..., Any]:
        """
        Decorator for library script. You should deocrate `main` function with this decorator if
        your script is a library script.

        :param title: The title of the script
        :param overlay: If True, the script will be displayed on the price chart as an overlay,
        :param dynamic_requests: Specifies whether the script can dynamically call functions from
        :param na_bool: Keep Pine v4/v5's three-state bool: a bool may be na (a history
                        before warm-up, ``na(bool)``, a fresh array or UDT bool); v6 has
                        no such state
        """
        script = cls()
        script.script_type = _script_type.library
        script.title = title
        script.shorttitle = title

        script.overlay = overlay
        script.dynamic_requests = dynamic_requests

        def decorator(func):
            # Register library main function if not already registered
            lib_entry = (script.title or 'Untitled Library', func)
            if lib_entry not in _registered_libraries:
                _registered_libraries.append(lib_entry)
            script.na_bool = na_bool
            return script._decorate()(func)

        return decorator


script = Script


class _Input:
    """
    Input functions
    """

    @overload
    def __call__(self, defval: TInput, /, **__) -> TInput: ...

    @overload
    def __call__(self, defval: TInput, title: str | None = None,
                 tooltip: str | None = None, inline: str | None = None, group: str | None = None,
                 display: _display.Display | None = None, active: bool | None = None,
                 *, _id: str = "", **__) -> TInput: ...

    def __call__(self, defval: Any, title: str | None = None,
                 tooltip: str | None = None, inline: str | None = None, group: str | None = None,
                 display: _display.Display | None = None, active: bool | None = None,
                 *, _id: str = "", **__) -> Any:
        """
        Adds an input to your script's settings, which allows you to provide configuration options

        :param defval: The default value of the input
        :param title: The title of the input
        :param tooltip: The tooltip of the input
        :param inline: Inputs with the same inline string are displayed on one line
        :param group: The group of the input
        :param display: Controls where the script will display the input's information
        :param active: UI-only in Pine (greys out the field); accepted for parity, ignored
        :param _id: The unique identifier of the input, it is filled by the InputTransformer
        :return: The input value from toml file or the default
        """
        input_type = type(defval).__name__.lower()
        if input_type == 'source':
            defval = str(defval)
        inputs[_id] = InputData(
            id=_id,
            input_type=input_type,
            defval=defval,
            title=title,
            tooltip=tooltip,
            inline=inline,
            group=group,
            display=display,
        )
        # A Pine int is a double at runtime: the generic face hands an int input
        # back the way ``input.int`` does
        if _id in _old_input_values:
            value = _old_input_values[_id]
            return safe_convert.safe_int(value) if input_type == 'int' else value
        return float(defval) if input_type == 'int' else defval

    # Pine's numeric inputs have TWO positional overloads after ``title``: the
    # minval/maxval/step form and the options form. A single Python parameter
    # list cannot bind both, so the implementations take ``*args`` and bind the
    # tail by inspecting the third argument (a tuple/list selects the options
    # form) — mirroring what the v6 reference publishes.
    _NUMERIC_RANGE_TAIL = ('minval', 'maxval', 'step', 'tooltip', 'inline', 'group',
                           'confirm', 'display', 'active')
    _NUMERIC_OPTIONS_TAIL = ('options', 'tooltip', 'inline', 'group',
                             'confirm', 'display', 'active')

    @classmethod
    def _bind_numeric_tail(cls, args: tuple, kwargs: dict) -> None:
        """
        Bind positional arguments after ``title`` into ``kwargs`` following
        Pine's two numeric input overloads.

        :param args: Positional arguments after ``defval`` and ``title``
        :param kwargs: Keyword arguments; bound names are added in place
        :raises TypeError: On too many positionals or a positional/keyword clash
        """
        if not args:
            return
        names = (cls._NUMERIC_OPTIONS_TAIL if isinstance(args[0], (tuple, list))
                 else cls._NUMERIC_RANGE_TAIL)
        if len(args) > len(names):
            raise TypeError("too many positional arguments for input")
        for name, value in zip(names, args):
            if name in kwargs:
                raise TypeError(f"input got multiple values for argument '{name}'")
            kwargs[name] = value

    # noinspection PyMethodOverriding
    @overload
    @classmethod
    def _int(cls, defval: int, title: str | None = None,
             minval: int | None = None, maxval: int | None = None, step: int | None = None,
             tooltip: str | None = None, inline: str | None = None, group: str | None = None,
             confirm: bool | None = False, display: _display.Display | None = None,
             active: bool | None = None, *, _id: str = "") -> PyneInt: ...

    # noinspection PyMethodOverriding
    @overload
    @classmethod
    def _int(cls, defval: int, title: str | None = None,
             options: tuple[int, ...] | None = None,
             tooltip: str | None = None, inline: str | None = None, group: str | None = None,
             confirm: bool | None = False, display: _display.Display | None = None,
             active: bool | None = None, *, _id: str = "") -> PyneInt: ...

    @classmethod
    def _int(cls, defval: int, title: str | None = None, *args,
             _id: str = "", **kwargs) -> PyneInt:
        """
        Adds an input to your script's settings, which allows you to provide configuration options
        to script users. This function adds a field for an integer input to the script's inputs.

        Positional arguments after ``title`` follow Pine v6's two overloads
        (``minval, maxval, step, ...`` or ``options, ...``); ``active`` is
        UI-only in Pine and is accepted but ignored.

        :param defval: The default value of the input
        :param title: The title of the input
        :param _id: The unique identifier of the input, it is filled by the InputTransformer
        :return: The input value from toml file or the default
        """
        cls._bind_numeric_tail(args, kwargs)
        inputs[_id] = InputData(
            id=_id,
            input_type='int',
            defval=defval,
            title=title,
            minval=kwargs.get('minval'),
            maxval=kwargs.get('maxval'),
            step=kwargs.get('step'),
            tooltip=kwargs.get('tooltip'),
            inline=kwargs.get('inline'),
            group=kwargs.get('group'),
            confirm=kwargs.get('confirm', False),
            options=kwargs.get('options'),
            display=kwargs.get('display'),
        )
        if _id in _old_input_values:
            return safe_convert.safe_int(_old_input_values[_id])
        return pine_int(defval) if defval == defval else na_int

    # ``active`` is UI-only in Pine: accepted for signature parity, never read
    # noinspection PyUnusedParameter
    @classmethod
    def _bool(cls, defval: bool, title: str | None = None,
              tooltip: str | None = None, inline: str | None = None, group: str | None = None,
              confirm: bool | None = False, display: _display.Display | None = None,
              active: bool | None = None,
              *, _id: str = "", **__) -> bool:
        """
        Adds an input to your script's settings, which allows you to provide configuration options
        to script users. This function adds a field for a boolean input to the script's inputs.

        :param defval: The default value of the input
        :param title: The title of the input
        :param tooltip: The tooltip of the input
        :param inline: Inputs with the same inline string are displayed on one line
        :param group: The group of the input
        :param confirm: If True, the user will be asked to confirm the input
        :param display: Controls where the script will display the input's information
        :param active: UI-only in Pine (greys out the field); accepted for parity, ignored
        :param _id: The unique identifier of the input, it is filled by the InputTransformer
        :return: The input value from toml file or the default
        """
        inputs[_id] = InputData(
            id=_id,
            input_type='bool',
            defval=defval,
            title=title,
            tooltip=tooltip,
            inline=inline,
            group=group,
            confirm=confirm,
            display=display,
        )
        return defval if _id not in _old_input_values else bool(_old_input_values[_id])

    # noinspection PyMethodOverriding
    @overload
    @classmethod
    def _float(cls, defval: float, title: str | None = None,
               minval: float | None = None, maxval: float | None = None,
               step: float | None = None,
               tooltip: str | None = None, inline: str | None = None, group: str | None = None,
               confirm: bool | None = False, display: _display.Display | None = None,
               active: bool | None = None, *, _id: str = "") -> PyneFloat: ...

    # noinspection PyMethodOverriding
    @overload
    @classmethod
    def _float(cls, defval: float, title: str | None = None,
               options: tuple[int | float, ...] | None = None,
               tooltip: str | None = None, inline: str | None = None, group: str | None = None,
               confirm: bool | None = False, display: _display.Display | None = None,
               active: bool | None = None, *, _id: str = "") -> PyneFloat: ...

    @classmethod
    def _float(cls, defval: float, title: str | None = None, *args,
               _id: str = "", **kwargs) -> PyneFloat:
        """
        Adds an input to your script's settings, which allows you to provide configuration options
        to script users. This function adds a field for a float input to the script's inputs.

        Positional arguments after ``title`` follow Pine v6's two overloads
        (``minval, maxval, step, ...`` or ``options, ...``); ``active`` is
        UI-only in Pine and is accepted but ignored.

        :param defval: The default value of the input
        :param title: The title of the input
        :param _id: The unique identifier of the input, it is filled by the InputTransformer
        :return: The input value from toml file or the default
        """
        cls._bind_numeric_tail(args, kwargs)
        inputs[_id] = InputData(
            id=_id,
            input_type='float',
            defval=defval,
            title=title,
            minval=kwargs.get('minval'),
            maxval=kwargs.get('maxval'),
            step=kwargs.get('step'),
            tooltip=kwargs.get('tooltip'),
            inline=kwargs.get('inline'),
            group=kwargs.get('group'),
            confirm=kwargs.get('confirm', False),
            options=kwargs.get('options'),
            display=kwargs.get('display'),
        )
        return defval if _id not in _old_input_values else safe_convert.safe_float(_old_input_values[_id])

    # ``active`` is UI-only in Pine: accepted for signature parity, never read
    # noinspection PyUnusedParameter
    @classmethod
    def string(cls, defval: str, title: str | None = None,
               options: tuple[str, ...] | None = None,
               tooltip: str | None = None, inline: str | None = None, group: str | None = None,
               confirm: bool | None = False,
               display: _display.Display | None = None, active: bool | None = None,
               *, _id: str = "", **__) -> str:
        """
        Adds an input to your script's settings, which allows you to provide configuration options
        to script users. This function adds a field for a string input to the script's inputs.

        :param defval: The default value of the input
        :param title: The title of the input
        :param tooltip: The tooltip of the input
        :param inline: Inputs with the same inline string are displayed on one line
        :param group: The group of the input
        :param confirm: If True, the user will be asked to confirm the input
        :param display: Controls where the script will display the input's information
        :param active: UI-only in Pine (greys out the field); accepted for parity, ignored
        :param options: A tuple of strings that the user can select from
        :param _id: The unique identifier of the input, it is filled by the InputTransformer
        :return: The input value from toml file or the default
        """
        inputs[_id] = InputData(
            id=_id,
            input_type='string',
            defval=defval,
            title=title,
            tooltip=tooltip,
            inline=inline,
            group=group,
            confirm=confirm,
            display=display,
            options=options,
        )
        return defval if _id not in _old_input_values else str(_old_input_values[_id])

    # ``active`` is UI-only in Pine: accepted for signature parity, never read
    # noinspection PyUnusedParameter
    @classmethod
    def color(cls, defval: Color, title: str | None = None,
              tooltip: str | None = None, inline: str | None = None, group: str | None = None,
              confirm: bool | None = False, display: _display.Display | None = None,
              active: bool | None = None,
              *, _id: str = "", **__) -> Color:
        """
        Adds an input to your script's settings, which allows you to provide configuration options
        to script users. This function adds a field for a color input to the script's inputs.

        :param defval: The default value of the input
        :param title: The title of the input
        :param tooltip: The tooltip of the input
        :param inline: Inputs with the same inline string are displayed on one line
        :param group: The group of the input
        :param confirm: If True, the user will be asked to confirm the input
        :param display: Controls where the script will display the input's information
        :param active: UI-only in Pine (greys out the field); accepted for parity, ignored
        :param _id: The unique identifier of the input, it is filled by the InputTransformer
        :return: The input value from toml file or the default
        """
        inputs[_id] = InputData(
            id=_id,
            input_type='color',
            defval=defval,
            title=title,
            tooltip=tooltip,
            inline=inline,
            group=group,
            confirm=confirm,
            display=display,
        )
        return defval if _id not in _old_input_values else Color(_old_input_values[_id])

    # ``active`` is UI-only in Pine: accepted for signature parity, never read
    # noinspection PyUnusedParameter
    @classmethod
    def source(cls, defval: str | Source | float, title: str | None = None,
               tooltip: str | None = None, inline: str | None = None, group: str | None = None,
               display: _display.Display | None = None, active: bool | None = None,
               confirm: bool | None = False,
               *, _id: str = "", **__) -> PyneFloat:
        """
        Adds an input to your script's settings, which allows you to provide configuration options
        to script users. This function adds a field for a source input to the script's inputs.

        Pine v6 positional order — uniquely among inputs, ``confirm`` comes LAST,
        after ``display`` and ``active``.

        :param defval: The name of the "source" registered in lib module,
                       like "open", "high", "low", "close", "hl2", "hlc3", "ohlc4"
        :param title: The title of the input
        :param tooltip: The tooltip of the input
        :param inline: Inputs with the same inline string are displayed on one line
        :param group: The group of the input
        :param display: Controls where the script will display the input's information
        :param active: UI-only in Pine (greys out the field); accepted for parity, ignored
        :param confirm: If True, the user will be asked to confirm the input
        :param _id: The unique identifier of the input, it is filled by the InputTransformer
        :return: The input value from toml file or the default
        """
        defval = str(defval)
        inputs[_id] = InputData(
            id=_id,
            input_type='source',
            defval=defval,
            title=title,
            tooltip=tooltip,
            inline=inline,
            group=group,
            confirm=confirm,
            display=display,
        )
        # We actually return a string here, but the InputTransformer will add a `getattr()` call to get the
        return defval if _id not in _old_input_values else _old_input_values[_id]  # type: ignore[return-value]

    # ``active`` is UI-only in Pine: accepted for signature parity, never read
    # noinspection PyUnusedParameter
    @classmethod
    def enum(cls, defval: TEnum, title: str | None = None,
             options: tuple[str, ...] | None = None,
             tooltip: str | None = None, inline: str | None = None, group: str | None = None,
             confirm: bool | None = False,
             display: _display.Display | None = None, active: bool | None = None,
             *, _id: str = "", **__) -> TEnum:
        """
        Adds an input to your script's settings, which allows you to provide configuration options
        to script users. This function adds a field for a enum input to the script's inputs.

        :param defval: The default value of the input
        :param title: The title of the input
        :param tooltip: The tooltip of the input
        :param inline: Inputs with the same inline string are displayed on one line
        :param group: The group of the input
        :param confirm: If True, the user will be asked to confirm the input
        :param display: Controls where the script will display the input's information
        :param active: UI-only in Pine (greys out the field); accepted for parity, ignored
        :param options: A tuple of strings that the user can select from
        :param _id: The unique identifier of the input, it is filled by the InputTransformer
        :return: The input value from toml file or the default
        """
        inputs[_id] = InputData(
            id=_id,
            input_type='enum',
            defval=defval,
            title=title,
            tooltip=tooltip,
            inline=inline,
            group=group,
            confirm=confirm,
            display=display,
            options=options,
        )
        if _id not in _old_input_values:
            return defval
        else:
            # Convert string value back to the specific enum type
            value = _old_input_values[_id]
            if isinstance(value, str):
                try:
                    return defval.__class__(value)
                except ValueError:
                    return defval
            return defval

    # We don't have interactive inputs, so price is stored as a float input; its
    # Pine positional order has no minval/maxval/step, so it cannot alias _float
    # ``active`` is UI-only in Pine: accepted for signature parity, never read
    # noinspection PyUnusedParameter
    @classmethod
    def price(cls, defval: float, title: str | None = None,
              tooltip: str | None = None, inline: str | None = None, group: str | None = None,
              confirm: bool | None = False, display: _display.Display | None = None,
              active: bool | None = None,
              *, _id: str = "", **__) -> PyneFloat:
        """
        Adds an input to your script's settings, which allows you to provide configuration options
        to script users. This function adds a field for a price input to the script's inputs.

        :param defval: The default value of the input
        :param title: The title of the input
        :param tooltip: The tooltip of the input
        :param inline: Inputs with the same inline string are displayed on one line
        :param group: The group of the input
        :param confirm: If True, the user will be asked to confirm the input
        :param display: Controls where the script will display the input's information
        :param active: UI-only in Pine (greys out the field); accepted for parity, ignored
        :param _id: The unique identifier of the input, it is filled by the InputTransformer
        :return: The input value from toml file or the default
        """
        return cls._float(defval, title, tooltip=tooltip, inline=inline, group=group,
                          confirm=confirm, display=display, _id=_id)

    # Pine's input.symbol has NO options: its third positional is tooltip, so it
    # cannot alias string (whose third positional is options)
    # ``active`` is UI-only in Pine: accepted for signature parity, never read
    # noinspection PyUnusedParameter
    @classmethod
    def symbol(cls, defval: str, title: str | None = None,
               tooltip: str | None = None, inline: str | None = None, group: str | None = None,
               confirm: bool | None = False, display: _display.Display | None = None,
               active: bool | None = None,
               *, _id: str = "", **__) -> str:
        """
        Adds an input to your script's settings, which allows you to provide configuration options
        to script users. This function adds a field for a symbol input to the script's inputs.

        :param defval: The default value of the input
        :param title: The title of the input
        :param tooltip: The tooltip of the input
        :param inline: Inputs with the same inline string are displayed on one line
        :param group: The group of the input
        :param confirm: If True, the user will be asked to confirm the input
        :param display: Controls where the script will display the input's information
        :param active: UI-only in Pine (greys out the field); accepted for parity, ignored
        :param _id: The unique identifier of the input, it is filled by the InputTransformer
        :return: The input value from toml file or the default
        """
        return cls.string(defval, title, tooltip=tooltip, inline=inline, group=group,
                          confirm=confirm, display=display, _id=_id)

    # Pine's input.text_area has neither options nor inline: its positional
    # order is defval, title, tooltip, group, confirm, display, active
    # ``active`` is UI-only in Pine: accepted for signature parity, never read
    # noinspection PyUnusedParameter
    @classmethod
    def text_area(cls, defval: str, title: str | None = None,
                  tooltip: str | None = None, group: str | None = None,
                  confirm: bool | None = False, display: _display.Display | None = None,
                  active: bool | None = None,
                  *, _id: str = "", **__) -> str:
        """
        Adds an input to your script's settings, which allows you to provide configuration options
        to script users. This function adds a field for a text area input to the script's inputs.

        :param defval: The default value of the input
        :param title: The title of the input
        :param tooltip: The tooltip of the input
        :param group: The group of the input
        :param confirm: If True, the user will be asked to confirm the input
        :param display: Controls where the script will display the input's information
        :param active: UI-only in Pine (greys out the field); accepted for parity, ignored
        :param _id: The unique identifier of the input, it is filled by the InputTransformer
        :return: The input value from toml file or the default
        """
        return cls.string(defval, title, tooltip=tooltip, group=group,
                          confirm=confirm, display=display, _id=_id)

    # time() returns UNIX timestamp in milliseconds (int); its Pine positional
    # order has no minval/maxval/step, so it cannot alias _int
    # ``active`` is UI-only in Pine: accepted for signature parity, never read
    # noinspection PyUnusedParameter
    @classmethod
    def time(cls, defval: int, title: str | None = None,
             tooltip: str | None = None, inline: str | None = None, group: str | None = None,
             confirm: bool | None = False, display: _display.Display | None = None,
             active: bool | None = None,
             *, _id: str = "", **__) -> PyneInt:
        """
        Adds an input to your script's settings, which allows you to provide configuration options
        to script users. This function adds a field for a time input to the script's inputs.

        :param defval: The default value of the input (UNIX timestamp in milliseconds)
        :param title: The title of the input
        :param tooltip: The tooltip of the input
        :param inline: Inputs with the same inline string are displayed on one line
        :param group: The group of the input
        :param confirm: If True, the user will be asked to confirm the input
        :param display: Controls where the script will display the input's information
        :param active: UI-only in Pine (greys out the field); accepted for parity, ignored
        :param _id: The unique identifier of the input, it is filled by the InputTransformer
        :return: The input value from toml file or the default
        """
        return cls._int(defval, title, tooltip=tooltip, inline=inline, group=group,
                        confirm=confirm, display=display, _id=_id)

    int = _int
    bool = _bool
    float = _float

    # These are incomplete, but good workaround
    session = string
    timeframe = string


# noinspection PyShadowingBuiltins
input = _Input()
