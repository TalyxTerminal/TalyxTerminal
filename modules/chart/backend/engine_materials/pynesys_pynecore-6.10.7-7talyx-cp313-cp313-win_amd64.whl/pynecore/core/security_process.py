"""
Security process loop — multiprocessing.Process target for request.security() contexts.

Each security context runs as a separate OS process with its own Python interpreter,
lib module, and Series state. The process loads its own OHLCV data, re-imports the
script module (triggering AST transformation), and runs the main() function per bar.

Communication with the chart process uses shared memory + Events (see security.py).

Two data-source modes (selected by the ``data_source`` arg type):

  Backtest / file mode (``str`` path):
      The subprocess opens a static ``.ohlcv`` file via :class:`OHLCVReader`
      and steps through it indexed by ``current_bar``. Used by historical
      runs and same-symbol HTF live runs (where the chart-side aggregator
      ships closed bars over the SyncBlock).

  Live cross-symbol mode (:class:`PluginSymbol`):
      The subprocess instantiates the named :class:`LiveProviderPlugin`,
      downloads warmup history in-memory via
      :func:`download_warmup_in_memory`, then streams closed bars from the
      provider's WS feed via :class:`LiveBarStreamer`. No ``.ohlcv`` file is
      involved.

Three flavors of advance are supported, distinguished by SyncBlock flags:

  (1) Historical closed bar — neither FLAG_IS_DEVELOPING nor FLAG_CLOSED_OVERRIDE
      is set. The subprocess pulls the next available bar from its source and
      runs ``main()`` with ``barstate.isconfirmed=True``. In file mode the
      source is the local ``.ohlcv`` file; in live cross-symbol mode it is the
      warmup buffer plus the WS stream.

  (2) Live closed bar — FLAG_CLOSED_OVERRIDE is set, FLAG_IS_DEVELOPING is not.
      The chart supplies the closed HTF OHLCV directly via the SyncBlock.
      Used by same-symbol HTF contexts where the chart-side
      :class:`HTFAggregator` builds the closed bar from the chart's own
      OHLCV stream.

  (3) Live developing bar — FLAG_IS_DEVELOPING is set. The chart supplies the
      in-progress HTF OHLCV via the SyncBlock. The subprocess re-runs ``main()``
      with ``barstate.isconfirmed=False`` against the same ``bar_index`` as the
      first developing tick of this period (Series.add → set, no new bar push).
      ``RootVarSnapshot`` rolls the root vectors' var slots back to the period
      baseline before each such re-execution, and ``RootChildSnapshot`` rolls
      the function instances back with it — the builtin machines carry state
      across periods (``ta.rma``'s accumulator, ``ta.tr``'s previous close), so
      dropping the instances would restart every ``ta.*`` from scratch on every
      re-tick and leave the expression permanently ``na``.
"""
from __future__ import annotations

import logging
import os
import sys
import threading
from collections import deque
from functools import partial
from pathlib import Path
from datetime import datetime, timedelta, UTC
from multiprocessing import parent_process
from time import monotonic
from typing import TYPE_CHECKING, Any, Callable, Iterator

from ..types.na import set_bool_na
from .security_shm import (
    SyncBlock, ResultBlock, write_na, FRONTIER_INF,
    FLAG_IS_DEVELOPING, FLAG_CLOSED_OVERRIDE, FLAG_DEV_HISTORICAL,
    FLAG_MORE_STEPS, FLAG_BATCH_ROUND, FLAG_DEV_BATCH_ROUND,
    RING_RESUME_ENTRIES, RING_RUNAHEAD_ENTRIES, is_ltf_window,
    is_ltf_chart_developing, is_ltf_live_phase,
)
from .security import (
    BarCalendar, DEV_BATCH_CLOSED, DEV_BATCH_DEVELOPING, actual_bar_close,
    create_security_protocol, inject_protocol, iter_dev_batch_records,
    same_calendar,
)
from .live_ltf_collector import LiveLtfCollector
from .plugin.live_provider import PluginSymbol
from .security_mp import apply_child_run_env

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from multiprocessing.process import BaseProcess
    from multiprocessing.synchronize import Condition, Lock as LockType
    from .live_runner import LiveBarStreamer
    from .security import DevBatchSpec
    from ..types.ohlcv import OHLCV

# Upper bound of one wait slice while throttled. The chart notifies the ring
# condition when it parks its watermark, so this only bounds how long a child
# sits before it re-checks ``stop_event`` (a chart that died notifies nobody).
_DEV_BATCH_WAIT_SECONDS = 0.5


def _start_parent_death_watchdog() -> None:
    """Hard-exit this security process if its parent dies without cleaning up.

    A security context runs as a ``daemon=True`` :class:`multiprocessing.Process`.
    A *clean* parent exit tears it down (daemon atexit + the runner's ``finally``
    that sets ``stop_event`` and joins). But a *hard* kill of the parent — a
    ``SIGKILL``, or a ``subprocess`` timeout that kills only the direct child —
    skips all of that: the child never receives ``stop_event``, and on macOS
    (where timed Event waits fall back to select() polling) spins at 100% CPU
    while pinning its OHLCV and interpreter memory. macOS has no
    ``PR_SET_PDEATHSIG``, so the portable safety net is a watchdog thread.

    The liveness signal must be the RUNNER, not ``os.getppid()``. Children are
    forked by the forkserver (``core/security_mp.py``), so their OS parent is
    that server — and the server itself outlives the runner: every client owns
    the write end of its "alive" pipe and ``connect_to_new_process`` passes that
    very fd on to the child, which never closes it. An orphaned security child
    therefore keeps the server alive and its ``getppid()`` never changes.
    :func:`multiprocessing.parent_process` tracks the LOGICAL parent instead:
    its sentinel is the read end of a pipe only the runner holds open, so it
    becomes ready the moment the runner dies, under any start method.

    The orphan then exits via ``os._exit`` — skipping atexit/``finally``, which
    could deadlock on shared memory the dead parent still holds.
    """
    parent = parent_process()
    if parent is None:  # not started through multiprocessing
        return

    def _watch(runner: BaseProcess) -> None:
        runner.join()  # blocks on the parent's sentinel, not a poll loop
        logger.warning(
            "Security process %d orphaned (parent %s gone); exiting.",
            os.getpid(), runner.pid,
        )
        os._exit(1)

    threading.Thread(target=_watch, args=(parent,), daemon=True,
                     name="sec-parent-watchdog").start()


# Warmup window for cross-symbol live security contexts. 500 bars matches the
# chart-side default in ``pyne run`` (``--from -500``); enough to seed any
# reasonable indicator without burning REST budget on excess history.
_DEFAULT_WARMUP_BARS = 500


# noinspection PyProtectedMember
def _run_rate_source_loop(
        sec_id: str,
        data_source: 'PluginSymbol',
        sync_block: SyncBlock,
        result_block: ResultBlock,
        advance_event,
        data_ready_event,
        done_event,
        stop_event,
        result_locks: 'dict[str, LockType]',
) -> None:
    """Minimal close-only loop for auto-spawned rate-source contexts.

    Skips Pine import and ``main()`` execution; every chart-side advance
    pushes the next warmup/live ``close`` into the ``ResultBlock`` so the
    :class:`CurrencyRateProvider` can read it as the live FX rate.
    """
    from .plugin import load_plugin
    from .plugin.live_provider import LiveProviderPlugin
    from .live_runner import download_warmup_in_memory, LiveBarStreamer
    from .security_shm import write_result, write_na
    from pynecore.lib.timeframe import _in_seconds

    provider_cls = load_plugin(data_source.provider_name)
    if not issubclass(provider_cls, LiveProviderPlugin):
        raise RuntimeError(
            f"Plugin '{data_source.provider_name}' is not a live provider; "
            f"cannot drive an auto-spawned rate-source context."
        )
    # ``ohlcv_dir`` is forwarded from the chart process so the child can
    # resolve per-exchange config overrides under ``<workdir>/config/plugins``
    # (e.g. the ``[binance]`` section of ``ccxt.toml``). No OHLCV file is
    # written either way — the writer is just attached for symmetry; the
    # rate-source loop reads bars directly into memory.
    provider = provider_cls(
        symbol=data_source.symbol,
        timeframe=data_source.timeframe,
        ohlcv_dir=data_source.ohlcv_dir,
        config=data_source.config,
    )
    if data_source.syminfo is not None:
        syminfo = data_source.syminfo
        provider.syminfo = syminfo
    else:
        syminfo = provider.update_symbol_info()

    tf_seconds = _in_seconds(data_source.timeframe)
    time_to = datetime.now(UTC)
    if data_source.time_from is not None:
        time_from = data_source.time_from
        if time_from.tzinfo is None:
            time_from = time_from.replace(tzinfo=UTC)
    else:
        time_from = time_to - timedelta(seconds=tf_seconds * _DEFAULT_WARMUP_BARS)

    # Start the WS streamer *before* the REST warmup download so the
    # subscription is open while warmup is in flight. If we downloaded
    # first, any bar that closes between the REST round-trip finishing
    # and the WS handshake completing would be lost: the warmup window
    # ends at ``time_to`` (captured above), and the not-yet-subscribed
    # WS cannot replay closes from before its connect time.
    # ``last_historical_timestamp=None`` because warmup hasn't run yet;
    # we dedupe the post-warmup catch-up below against the warmup tail.
    live_streamer = LiveBarStreamer(
        provider, data_source.symbol, data_source.timeframe,
        syminfo=syminfo,
        last_historical_timestamp=None,
    )
    live_streamer.start()
    bar_buffer = download_warmup_in_memory(provider, time_from, time_to)
    last_warmup_ts = bar_buffer[-1].timestamp if bar_buffer else None
    # Drain anything the WS already queued and dedupe against warmup.
    # Streaming continues; later ``pop_new_closed_bars()`` calls only
    # need a forward-timestamp check, which the buffer-walk already does.
    # Equal-timestamp WS closes refine the warmup tail (providers whose
    # REST window includes the currently forming candle deliver the true
    # final close via WS at the same timestamp), so we overwrite rather
    # than drop — mirroring the chart's live path which lets equal
    # timestamps through for refinement.
    if last_warmup_ts is not None:
        for _bar in live_streamer.pop_new_closed_bars():
            if _bar.timestamp == last_warmup_ts and bar_buffer:
                bar_buffer[-1] = _bar
            elif _bar.timestamp > last_warmup_ts:
                bar_buffer.append(_bar)
    else:
        bar_buffer.extend(live_streamer.pop_new_closed_bars())

    try:
        current_bar = 0
        # Track the most recently published close so multiple advance
        # cycles within a single chart bar (e.g. ``calc_on_every_tick``
        # strategies, or indicators that resignal the rate sources every
        # script invocation) can re-publish the same value instead of
        # falling back to ``na`` once ``bar_buffer`` is fully drained up
        # to the current chart timestamp. ``CurrencyRateProvider`` requires
        # a real rate for ``request.security(..., currency=…)`` conversion;
        # writing NaN on the second call would stop the conversion mid-bar.
        last_close: float | None = None
        while True:
            advance_event.wait()
            advance_event.clear()
            if stop_event.is_set():
                break

            target_time = sync_block.get_target_time(sec_id)
            # Same dedupe applies forever: streamer was subscribed before
            # warmup, so the first batch may overlap warmup; subsequent
            # batches monotonically advance and the timestamp check is a
            # no-op once ``last_warmup_ts`` is past. Equal-timestamp closes
            # refine the partial warmup tail (see comment above the initial
            # drain) — overwrite rather than drop.
            for _bar in live_streamer.pop_new_closed_bars():
                if last_warmup_ts is None:
                    bar_buffer.append(_bar)
                elif _bar.timestamp == last_warmup_ts and bar_buffer:
                    bar_buffer[-1] = _bar
                elif _bar.timestamp > last_warmup_ts:
                    bar_buffer.append(_bar)

            bars_run = False
            while current_bar < len(bar_buffer):
                bar = bar_buffer[current_bar]
                # A UTC->tz datetime roundtrip preserves the instant, so the
                # raw timestamp is already the answer
                bar_time_ms = bar.timestamp
                if bar_time_ms > target_time:
                    break
                last_close = float(bar.close)
                with result_locks[sec_id]:
                    write_result(result_block, sync_block, last_close)
                current_bar += 1
                bars_run = True

            if not bars_run:
                with result_locks[sec_id]:
                    if last_close is not None:
                        # Re-publish the last known close so a second
                        # advance within the same chart bar still sees a
                        # valid rate.
                        write_result(result_block, sync_block, last_close)
                    else:
                        # No bar has been consumed yet — the rate feed has
                        # nothing to publish; signal NaN so the consumer
                        # falls back to whatever default it has.
                        write_na(result_block, sync_block)

            data_ready_event.set()
            done_event.set()
    finally:
        # Whatever ended this loop — a shutdown, an exception, the end of the
        # feed — release anyone still waiting on this round. A sibling's death
        # sets EVERY child's stop_event, so this child can leave with a round
        # outstanding; it then exits cleanly, its own watcher fires nothing,
        # and an untimed chart wait on these events would never wake.
        data_ready_event.set()
        done_event.set()
        live_streamer.stop()
        result_block.close()
        sync_block.close()


def _collect_in_period_intrabars(
        bar_buffer: 'list[OHLCV]',
        next_idx: int,
        period_end_exclusive: int,
        ltf_span_ms: int,
        chart_developing: bool,
        grace_seconds: float,
        wait_for_bars: 'Callable[[float], list[OHLCV]]',
        ingest: 'Callable[[OHLCV], None]',
        *,
        now: 'Callable[[], float] | None' = None,
) -> 'tuple[list[OHLCV], int]':
    """Collect a chart period's closed intrabars, blocking (bounded) for a lagging
    final intrabar on a confirmed chart bar.

    Advances ``next_idx`` through ``bar_buffer`` collecting every closed intrabar
    inside ``[period_start, period_end_exclusive)`` (future-period bars are left
    for the next round). On a developing chart bar the partial collection is
    returned at once. On a confirmed chart bar the published array must be the
    FULL closed period, so when the final in-period intrabar
    (``ts >= period_end_exclusive - ltf_span_ms``) is still missing the loop waits
    up to ``grace_seconds`` for the streamer to deliver it, ingesting late bars as
    they arrive — unless a later-period bar is already buffered, which means the
    final intrabar is genuinely gone (a provider gap) and waiting would only burn
    the grace. Warmup is a no-op here (its bars are already buffered).

    The clock (``now``) and the streamer wait/ingest are injected so the loop is
    deterministically testable without real time; ``now`` defaults to
    :func:`time.monotonic`.

    :param bar_buffer: The shared, append-only intrabar buffer; ``ingest`` mutates
        this same list, so bars delivered by ``wait_for_bars`` become visible to
        the next collect pass.
    :param next_idx: Cursor into ``bar_buffer`` of the first not-yet-consumed bar.
    :param period_end_exclusive: Exclusive end of the chart period, in ms.
    :param ltf_span_ms: One LTF intrabar span, in ms (defines the final-intrabar
        open as ``period_end_exclusive - ltf_span_ms``).
    :param chart_developing: True for a forming chart bar (return the partial
        collection without waiting), False for a confirmed one.
    :param grace_seconds: Maximum seconds to block for the lagging final intrabar.
    :param wait_for_bars: ``(timeout) -> list[OHLCV]`` blocking wait on the
        streamer, up to ``timeout`` seconds.
    :param ingest: ``(bar) -> None`` appends a streamer bar into ``bar_buffer``.
    :param now: ``() -> float`` monotonic clock; defaults to ``time.monotonic``.
    :return: ``(collected, next_idx)`` — the in-period intrabars and the advanced
        cursor.
    """
    if now is None:
        now = monotonic
    collected: 'list[OHLCV]' = []
    final_open = period_end_exclusive - ltf_span_ms
    deadline = now() + grace_seconds
    while True:
        while next_idx < len(bar_buffer):
            _b = bar_buffer[next_idx]
            if _b.timestamp >= period_end_exclusive:
                break
            collected.append(_b)
            next_idx += 1
        if chart_developing:
            break
        if collected and collected[-1].timestamp >= final_open:
            break
        # A bar beyond this period is already buffered: the stream has advanced
        # past the period end, so the final in-period intrabar is genuinely
        # missing (a gap) — stop waiting and publish what we have rather than
        # burning the full grace.
        if next_idx < len(bar_buffer):
            logger.warning(
                "Live LTF period ending %d ms missing its final intrabar "
                "(stream advanced past it); publishing the gap as-is",
                period_end_exclusive,
            )
            break
        _remaining = deadline - now()
        if _remaining <= 0:
            logger.warning(
                "Live LTF period ending %d ms incomplete after %.0fs grace; "
                "publishing without the final intrabar",
                period_end_exclusive, grace_seconds,
            )
            break
        for _sb in wait_for_bars(_remaining):
            ingest(_sb)
    return collected, next_idx


def _heikinashi_step(prev_open: float | None, prev_close: float | None,
                     o: float, h: float, lo: float, c: float
                     ) -> tuple[float, float, float, float]:
    """One Heikin Ashi recurrence step over ordinary OHLC.

    ``prev_open``/``prev_close`` are the previous bar's Heikin Ashi open/close
    (``None`` on the seed bar, where the open falls back to ``(o + c) / 2``).

    :return: ``(ha_open, ha_high, ha_low, ha_close)``.
    """
    ha_close = (o + h + lo + c) / 4.0
    ha_open = (o + c) / 2.0 if (prev_open is None or prev_close is None) \
        else (prev_open + prev_close) / 2.0
    return ha_open, max(h, ha_open, ha_close), min(lo, ha_open, ha_close), ha_close


# noinspection PyProtectedMember
def security_process_main(
        sec_ids: list[str],
        script_path: str,
        data_source: 'str | PluginSymbol',
        sync_block_name: str,
        all_sec_ids: list[str],
        # Events (multiprocessing.Event — picklable across spawn), per served sid
        data_ready_events,
        advance_event,
        done_event_map,
        stop_event,
        is_ltf: bool = False,
        result_locks: 'dict[str, LockType] | None' = None,
        ohlcv_fields: 'dict[str, list[str] | None] | None' = None,
        ohlcv_tuple: 'dict[str, bool] | None' = None,
        slice_main: 'str | None' = None,
        chart_type: 'str | None' = None,
        chart_timeframe: 'str | None' = None,
        plain_ltf: bool = False,
        chart_type_warmup: 'str | None' = None,
        registry: 'dict[str, dict] | None' = None,
        chart_calendar=None,
        ring_conditions: 'dict[str, Condition] | None' = None,
        consumer_ids: 'dict[str, list[str]] | None' = None,
        registry_pipe=None,
        chart_ring_capacity: 'dict[str, int] | None' = None,
        chart_ring_arena: 'dict[str, int] | None' = None,
        script_inputs: 'dict[str, Any] | None' = None,
        script_settings: 'dict[str, Any] | None' = None,
        dev_batch_spec: 'DevBatchSpec | None' = None,
        run_env: 'dict[str, str] | None' = None,
):
    assert result_locks is not None, "result_locks must be provided by script_runner"
    """
    Entry point for a security process (multiprocessing.Process target).

    Re-registers import hooks (needed for spawn mode on macOS/Windows),
    re-imports the script, and runs the bar loop.

    :param sec_ids: The security contexts this process serves, PRIMARY first.
        One process serves a whole GROUP when the transformer proved its members
        resolve to the same feed: they share this bar loop and the group's single
        ``main()`` clone, each keeping its own result block, ring and
        ``data_ready``. Only the primary's SyncBlock slot carries scheduling —
        target time, flags, round context and the advance event are read from it
        — while ``rounds_done`` and the done event are raised for every member,
        so the chart's per-sid wait path is unchanged
    :param script_path: Path to the script .py file
    :param data_source: Either a path to an ``.ohlcv`` file (backtest / file
                        mode) or a :class:`PluginSymbol` describing the live
                        provider, symbol, timeframe and pre-loaded config.
    :param sync_block_name: SharedMemory name of the SyncBlock
    :param all_sec_ids: List of ALL security context IDs (for cross-reads)
    :param data_ready_events: Per served sid, the event signaling that this
        context's value is available for reading
    :param advance_event: Event signaling this process should advance (the
        primary's)
    :param done_event_map: Per served sid, the event signaling that this process
        finished its current round
    :param stop_event: Event signaling this process should shut down
    :param is_ltf: If True, accumulate expression values into array per round
    :param ohlcv_fields: Per served sid, the raw price series
        (open/high/low/close/volume/hl2/hlc3/ohlc4/hlcc4) its expression consists
        of, or None. When EVERY member has one, the per-bar run skips main() and
        writes those fields straight from the bar; a group mixing passthrough and
        computed members runs the clone, whose write blocks cover both.
    :param ohlcv_tuple: Per served sid, True when its ``ohlcv_fields`` came from
        a tuple/list expression (write a tuple), False for a scalar expression.
    :param slice_main: Name of this context's sliced ``main()`` clone in the
        script module (``transformers/security_slice.py``). When set, the clone
        runs on every bar in place of ``main()``: it holds the backward slice of
        ``main()``'s statements this context's ``__sec_write__`` can depend on.
    :param chart_type: Synthetic chart type requested via ``ticker.heikinashi()``
        etc. (currently only ``"heikinashi"``). When set, the child applies the
        per-bar chart-type transform to every bar before the script reads it (so
        backtest and live both work) and flips the matching ``chart.*`` builtin.
    :param chart_timeframe: The chart's (main-series) timeframe. Stored in
        ``lib._main_timeframe`` so ``timeframe.main_period`` in this child reports
        the chart TF instead of the context's own period (the child has no
        ``lib._script`` to carry it).
    :param plain_ltf: Scalar ``request.security()`` with a timeframe finer than
        the chart's. The chart signals every bar with the bar's own period as
        the target; an empty round (no intrabar in the period — a feed gap)
        must keep the previous value (TradingView ``gaps_off`` forward-fill)
        instead of writing ``na``.
    :param chart_type_warmup: ``.ohlcv`` at this context's resolution reaching
        before the chart's first bar, used ONLY to seed the ``chart_type``
        recurrence (the context's bars still come from the chart). ``None``
        starts the transform cold on the first bar.
    :param registry: Peer records for every resolved security context, keyed by
        sec_id — timeframe, calendar, ``is_dwm``, ``gaps_on``, ``has_producer``,
        plus this context's own ``depends`` and ``in_loop``. Children build
        their peer state from it lazily, on the first read of each peer.
    :param chart_calendar: The chart's trading schedule, for the chart-as-of cap.
    :param ring_conditions: Per-sid ``multiprocessing.Condition`` created by the
        parent; a producer notifies its own, a consumer waits on the peer's.
    :param consumer_ids: Per served sid, the sids consuming it. Empty means no
        security consumer; that member then publishes a ring only when the CHART
        consumes it (``chart_ring_capacity``).
    :param chart_ring_capacity: Per served sid, non-zero when the chart runs that
        member's historical phase as ONE batch round and pairs the values out of
        the ring instead of handshaking per bar. The chart is then a ring
        consumer (``SyncBlock.chart_index``) and the ring is pre-sized to this
        many entries, so the whole batch fits without repeated reallocation.
    :param chart_ring_arena: Per served sid, the payload arena size in bytes to
        pre-size the chart-consumed ring with.
    :param registry_pipe: Child end of the parent's registry pipe. The chart
        pushes a context's record down it the moment it resolves one whose
        symbol or timeframe only exists at runtime — such a context can be a
        dependency of a child that was already spawned, so its record cannot
        have been in that child's snapshot.
    :param script_inputs: The runner's programmatic input overrides. They are
        applied while this process imports the script, so the child computes
        its context with the very values the chart runs with instead of the
        ``.toml`` (or source) defaults.
    :param script_settings: The runner's programmatic script setting overrides,
        applied the same way as ``script_inputs``.
    :param dev_batch_spec: What to reproduce a historical DEVELOPING batch's
        round sequence from (see :func:`security.iter_dev_batch_records`), or
        ``None``. The chart launches ONE round for it
        (``FLAG_DEV_BATCH_ROUND``) and this process produces every record of
        the sequence and replays it as a round of its own, running ahead of the
        chart while it walks its bars.
    :param run_env: The runner's ``PYNE*`` environment at spawn time
        (``security_mp.child_run_env``), or ``None`` to leave the inherited one
        alone. A forkserver child inherits the SERVER's environment, frozen at
        the first spawn, so every per-run switch has to travel with the process
        instead; the snapshot replaces the prefix wholesale, an empty one
        included (``security_mp.apply_child_run_env``).
    """
    # Safety net first: exit if the parent is hard-killed (see the watchdog docstring).
    _start_parent_death_watchdog()

    # Before anything reads a switch — the import hook below already consults
    # ``PYNE_NO_SECURITY_SLICE``. The child's own later writes still win, which
    # is what ``PYNE_SAVE_SCRIPT_TOML`` relies on.
    if run_env is not None:
        apply_child_run_env(run_env)

    # Re-register import hooks (spawn mode starts a fresh Python process)
    from . import import_hook  # noqa

    # Adopt the chart run's ``timenow`` pin: a spawned child imports
    # ``pynecore.lib`` fresh, and a context reading the clock while the chart
    # body reads the anchored instant would put the two out of step.
    _pinned_timenow = os.environ.get('PYNE_TIMENOW_MS')
    if _pinned_timenow:
        from pynecore import lib as _lib
        _lib._timenow_ms = int(_pinned_timenow)

    # The group's primary drives every scheduling read below; the other members
    # only carry results.
    sec_id = sec_ids[0]
    ohlcv_fields = ohlcv_fields or {}
    ohlcv_tuple = ohlcv_tuple or {}
    consumer_ids = consumer_ids or {}
    chart_ring_capacity = chart_ring_capacity or {}
    chart_ring_arena = chart_ring_arena or {}

    # Open shared memory blocks
    sync_block = SyncBlock(all_sec_ids, create=False, name=sync_block_name)
    result_blocks = {
        _sid: ResultBlock(_sid, create=False, version=0,
                          prefix=sync_block.block_prefix(_sid))
        for _sid in sec_ids
    }
    result_block = result_blocks[sec_id]
    data_ready_event = data_ready_events[sec_id]
    done_event = done_event_map[sec_id]

    # Rate-source-only contexts skip the Pine machinery entirely: they only
    # exist so the chart-side ``CurrencyRateProvider`` can read a fresh
    # ``close`` from the result block. Dispatch before any script import.
    if isinstance(data_source, PluginSymbol) and data_source.is_rate_source:
        _run_rate_source_loop(
            sec_id, data_source, sync_block, result_block,
            advance_event, data_ready_event, done_event, stop_event,
            result_locks,
        )
        return

    # ── Source dispatch: file (backtest) or live provider (cross-symbol live) ──
    from .syminfo import SymInfo
    from ..types.ohlcv import OHLCV
    live_streamer: 'LiveBarStreamer | None' = None
    authoritative_observations = False
    bar_buffer: list[OHLCV] = []
    # Watermark used by the live path to dedupe streamer bars against the
    # warmup window — the streamer is subscribed *before* the REST warmup
    # download, so the first batch from ``pop_new_closed_bars()`` may
    # overlap warmup. ``None`` in file mode or when warmup yielded zero bars.
    last_warmup_ts: int | None = None
    # Grace window (seconds) the closed-only loop blocks on the streamer
    # queue waiting for a bar at ``target_time`` that has not yet been
    # published by the upstream WS feed. Cross-exchange symbol closes can
    # land a few seconds after the chart symbol's close, and the chart
    # process already advanced ``last_confirmed`` for this period — without
    # blocking here the loop would emit ``na`` and never get re-signaled.
    # Set when the live cross-symbol path is initialised below.
    live_bar_grace_seconds: float = 0.0
    # Warmup horizon (ms): the instant the REST warmup ended. The live LTF-window
    # path uses it to drop a still-forming warmup tail bar. Set in the live branch.
    warmup_horizon_ms: int = 0
    # Timestamp of a warmup tail bar a WS close refined in place (live path only).
    ws_refined_tail_ts: float | None = None

    if isinstance(data_source, PluginSymbol):
        # Live cross-symbol path: own provider + warmup download + WS stream.
        from .plugin import load_plugin
        from .plugin.live_provider import LiveProviderPlugin
        from . import live_runner
        from pynecore.lib.timeframe import _in_seconds

        provider_cls = load_plugin(data_source.provider_name)
        if not issubclass(provider_cls, LiveProviderPlugin):
            raise RuntimeError(
                f"Plugin '{data_source.provider_name}' is not a live provider; "
                f"cannot drive cross-symbol live request.security."
            )
        # ``ohlcv_dir`` is forwarded from the chart process so the child can
        # resolve per-exchange config overrides under
        # ``<workdir>/config/plugins`` (e.g. the ``[binance]`` section of
        # ``ccxt.toml``). The OHLCV writer is attached but no file is
        # written — warmup goes through ``download_warmup_in_memory``.
        live_provider = provider_cls(
            symbol=data_source.symbol,
            timeframe=data_source.timeframe,
            ohlcv_dir=data_source.ohlcv_dir,
            config=data_source.config,
        )
        authoritative_observations = bool(getattr(live_provider, "authoritative_observations", False))
        # The chart may have pre-fetched syminfo to keep both sides in sync
        # with a single REST round-trip; fall back to a local call if not.
        if data_source.syminfo is not None:
            syminfo = data_source.syminfo
            live_provider.syminfo = syminfo
        else:
            syminfo = live_provider.update_symbol_info()

        tf_seconds = _in_seconds(data_source.timeframe)
        # Mirror ``live_runner.bar_grace`` — 15..30s tracks how long an
        # exchange typically lags between bar close and WS publish, scaled
        # to the bar period (sub-15s windows would race against jitter).
        live_bar_grace_seconds = max(15.0, min(tf_seconds * 0.5, 30.0))
        time_to = (datetime.fromtimestamp(live_provider.observation_time_ms() / 1000.0, UTC)
                   if authoritative_observations else datetime.now(UTC))
        if authoritative_observations:
            live_bar_grace_seconds = 0.0
        warmup_horizon_ms = int(time_to.timestamp() * 1000)
        if data_source.time_from is not None:
            time_from = data_source.time_from
            if time_from.tzinfo is None:
                time_from = time_from.replace(tzinfo=UTC)
        else:
            time_from = time_to - timedelta(seconds=tf_seconds * _DEFAULT_WARMUP_BARS)

        # Start the WS streamer *before* the REST warmup so the subscription
        # is open while warmup is in flight. If we downloaded first, any bar
        # closing in the (REST-done → WS-connected) window would be lost.
        # ``last_historical_timestamp=None`` because warmup hasn't run yet;
        # the post-warmup catch-up below dedupes against the warmup tail.
        if authoritative_observations:
            class AcceptedObservationStream:
                # A captured snapshot is already accepted. No concurrent queue
                # or wall-clock producer can add observations behind its back.
                def __init__(self):
                    self.seen = {}
                    self.pending = []
                    self.developing = None
                    self.historical = True

                @staticmethod
                def identity(bar):
                    import json
                    return json.dumps([bar.timestamp, bar.open, bar.high, bar.low,
                        bar.close, bar.volume, bar.extra_fields, bar.is_closed], sort_keys=True)

                def prime(self, bars):
                    self.seen = {bar.timestamp: self.identity(bar) for bar in bars}

                def start(self):
                    pass

                def stop(self):
                    pass

                def refresh(self, target_time, round_tick):
                    closed, self.developing, self.historical = live_provider.read_security_observation(
                        target_time, round_tick)
                    for bar in closed:
                        prior = self.seen.get(bar.timestamp)
                        identity = self.identity(bar)
                        if prior is not None:
                            if prior != identity:
                                raise RuntimeError("Accepted closed secondary history changed; native replay required")
                            continue
                        if self.seen and bar.timestamp <= max(self.seen):
                            raise RuntimeError("Accepted secondary history inserted behind the native cursor")
                        self.seen[bar.timestamp] = identity
                        self.pending.append(bar)
                    return list(self.pending), self.developing, self.historical

                def pop_new_closed_bars(self):
                    result, self.pending = self.pending, []
                    return result

                def wait_for_bars(self, timeout):
                    return self.pop_new_closed_bars()

                def peek_developing_bar(self):
                    return self.developing

            live_streamer = streamer = AcceptedObservationStream()
        else:
            live_streamer = streamer = live_runner.LiveBarStreamer(
                live_provider, data_source.symbol, data_source.timeframe,
                syminfo=syminfo,
                last_historical_timestamp=None,
            )
        streamer.start()
        bar_buffer = live_runner.download_warmup_in_memory(live_provider, time_from, time_to)
        last_warmup_ts = bar_buffer[-1].timestamp if bar_buffer else None
        if authoritative_observations:
            streamer.prime(bar_buffer)
        # Equal-timestamp WS closes refine the warmup tail — providers whose
        # REST window includes the currently forming candle deliver the true
        # final close via WS at the same timestamp, so overwrite rather than
        # drop. Mirrors the chart's live path (``live_ohlcv_generator``) which
        # lets equal timestamps through for refinement. A tail refined this way
        # is authoritative *and* already consumed from the streamer queue, so the
        # LTF pop loop below must keep it (the stream will not redeliver it).
        if last_warmup_ts is not None:
            for _bar in streamer.pop_new_closed_bars():
                if _bar.timestamp == last_warmup_ts and bar_buffer:
                    bar_buffer[-1] = _bar
                    ws_refined_tail_ts = _bar.timestamp
                elif _bar.timestamp > last_warmup_ts:
                    bar_buffer.append(_bar)
        else:
            bar_buffer.extend(streamer.pop_new_closed_bars())
        reader = None
    else:
        # File mode (backtest, same-symbol live with HTF aggregator).
        ohlcv_path = data_source
        from .ohlcv import OHLCVReader
        reader = OHLCVReader(ohlcv_path)
        reader.open()

        ohlcv_base = Path(ohlcv_path)
        toml_path = ohlcv_base.with_suffix('.toml')
        syminfo = SymInfo.load_toml(toml_path)

    # Gap-compacted bar view for HTF security contexts on a LEGACY feed. That
    # format cannot express a gap, so non-trading session/calendar gaps were
    # forward-filled with ``volume == -1`` flat bars: a session-gapped intraday
    # feed (e.g. a 720-minute HTF on Bursa palm oil) became a continuous 24h grid,
    # and a weekday-only D/W/M feed grew synthetic weekend/holiday bars. The chart
    # side drops these via ``read_from(skip_gaps=True)`` (and ``bar_opens`` rides
    # the real opens only); the security child must too. Otherwise the child
    # re-runs ``main()`` over the phantom bars: bar-count history reads
    # (``ta.highest``/``ta.lowest``/``[n]``) span fewer real periods than
    # TradingView, and stateful series like ``ta.sma(close, 3)`` accumulate the
    # flat fill bars (a Friday->Monday daily gap would otherwise average two
    # synthetic weekend closes). TradingView builds its HTF series from real bars
    # only. LTF keeps the fills (its intrabar windows are intentionally
    # continuous). Same-TF cross-symbol compacts too: a session-bounded feed on a
    # 24/7 chart (TVC:US10Y on BINANCE:BTCUSDT) would otherwise run stateful
    # indicators (``ta.ema``) over thousands of flat weekend/overnight fills,
    # dragging their state toward the last close while TradingView's are frozen
    # between real bars. The chart side pairs this with the ``bar_opens`` clamp in
    # ``_get_confirmed_time``: in a gap nothing new is confirmed, so the prior real
    # value forward-fills (TV ``gaps_off``) instead of the child advancing into an
    # empty window and writing ``na``. A file that declares its own period stores
    # real bars only, so it is never scanned. ``None`` = no compaction.
    # Only a legacy feed can hold phantom gap records; the current format stores
    # real bars only, so a negative volume there is the source's own value and
    # must be left alone.
    is_legacy_feed = reader is not None and reader.period is None

    real_index_map: list[int] | None = None
    if reader is not None and is_legacy_feed and not is_ltf:
        from pynecore.lib.timeframe import _in_seconds
        if _in_seconds(syminfo.period) > 0:
            # Mirror ``read_from(skip_gaps=True)`` exactly: a gap is ``volume < 0``
            # (the legacy -1 fill). ``>= 0`` would also drop NaN-volume real bars
            # (no-volume instruments import as ``volume == na``), which the reader keeps.
            rim = [i for i in range(reader.size) if not (reader.read(i).volume < 0)]
            if len(rim) != reader.size:
                real_index_map = rim

    # Import the script module (triggers AST transformation)
    from .script_runner import (import_script, _round_price, _set_lib_properties,
                                _set_lib_syminfo_properties)
    from pynecore import lib
    from pynecore.lib import barstate
    from pynecore.core import instance_state, script as script_mod
    from ..types.ohlcv import OHLCV

    # Set syminfo BEFORE importing the script
    _set_lib_syminfo_properties(syminfo)

    # ``timeframe.main_period`` must report the chart TF, not this context's own
    # period — the child has no ``lib._script`` to carry it, so propagate it here.
    if chart_timeframe is not None:
        lib._main_timeframe = chart_timeframe

    # Chart-type context (``ticker.heikinashi()``): this child evaluates the
    # script on Heikin Ashi candles, so the chart-type builtins must reflect the
    # security context, not the parent's standard chart. The ``chart`` module is
    # this process's own replica, so the parent's flags stay untouched.
    if chart_type == 'heikinashi':
        from pynecore.lib import chart
        chart.is_heikinashi = True
        chart.is_standard = False

    # Parse timezone
    from pynecore.lib import _parse_timezone
    tz = _parse_timezone(syminfo.timezone)

    # This context's OWN trading schedule, straight from its own syminfo — more
    # authoritative than the parent's registry copy, which a live provider path
    # may not have been able to fill. Its bars' scheduled closes and the as-of
    # calendar extension both ride it.
    from .resampler import grid_mode as _grid_mode
    own_calendar = BarCalendar(
        tz=tz,
        opening_hours=tuple(syminfo.opening_hours or ()),
        session_starts=tuple(syminfo.session_starts or ()),
        corrections=syminfo.session_corrections or None,
        grid_mode=_grid_mode(syminfo.type, syminfo.opening_hours, syminfo.prefix),
    )
    own_timeframe = str(syminfo.period)
    registry = dict(registry or {})
    # Every member runs on this very feed, so they all get the calendar this
    # process read from its own syminfo.
    for _member in sec_ids:
        _member_record = dict(registry.get(_member) or {})
        _member_record['calendar'] = own_calendar
        registry[_member] = _member_record
    own_record = registry[sec_id]

    # A D/W/M context keeping the CHART's calendar is asked as far as the end of
    # the scheduled break the round's tick falls in — that is the as-of both the
    # chart (:func:`chart_asof`) and a peer child (``_peer_asof``) derive for it.
    # Any other context is asked no further than the tick itself.
    own_dwm_on_chart_calendar = (
        bool(own_record.get('is_dwm')) and chart_calendar is not None
        and same_calendar(own_calendar, chart_calendar))

    # Create protocol functions for security context
    (signal_fn, write_fn, read_fn, wait_fn, cleanup, flush_fn,
     ltf_take_value, ltf_publish, ltf_buffer_len, sec_ctx, after_bar,
     finish_ring, prime_ring, release_unwritten) = create_security_protocol(
        sec_ids, sync_block, result_blocks, all_sec_ids, result_locks, is_ltf=is_ltf,
        registry=registry, chart_calendar=chart_calendar,
        ring_conditions=ring_conditions, consumer_ids=consumer_ids,
        stop_event=stop_event, data_ready_events=data_ready_events,
        registry_pipe=registry_pipe,
        chart_ring_capacity=chart_ring_capacity,
        chart_ring_arena=chart_ring_arena,
    )

    # Mintick decimals for OHLC grid-snapping in ``_set_lib_properties``
    # (``None`` when the symbol has no real mintick -> falls back to the
    # significant-digit clean-up). Mirrors ``ScriptRunner._round_decimals``.
    from .syminfo import mintick_decimals
    _sec_mintick = getattr(syminfo, 'mintick', 0.0) or 0.0
    round_decimals = mintick_decimals(_sec_mintick) if _sec_mintick > 0 else None
    # This context's own feed decides whether its bars need the float32 storage
    # clean-up — a child can run on a different file, and format, than the chart.
    # Without a reader this is the live provider path: warmup and streamed bars
    # carry the provider's own values and never touched storage, so the clean-up
    # there could only truncate what the feed served.
    lossless_volume = reader.lossless_volume if reader is not None else True
    lossless_prices = reader.lossless_prices if reader is not None else True

    # A security child is a read-only replica of the user's script, not a place
    # to persist config. ``script.indicator``/``strategy`` re-saves the script's
    # ``.toml`` on import when ``pytest`` is absent (always true in a spawned
    # child), so several contexts would race to rewrite — and can corrupt — the
    # same user file. Disable the save for this process before importing.
    os.environ['PYNE_SAVE_SCRIPT_TOML'] = '0'

    # The runner's programmatic inputs and settings override the .toml values in
    # the chart process; this process loads the same script from scratch, so the
    # import must apply them too or the child would silently run a differently
    # configured script than the chart it feeds.
    script_module = import_script(Path(script_path), inputs=script_inputs,
                                  settings=script_settings)

    # Inject security protocol into module globals. Imported library modules can
    # contain request.security() calls too, so their transformed code references
    # __active_security__ / __sec_read__ / … — every module whose main runs in
    # this child needs the protocol, exactly like the chart side (see
    # ScriptRunner's sec_modules). Injecting only the main module leaves a
    # library main raising NameError on __active_security__.
    sec_modules: list = [script_module]
    for _reg_title, _reg_main in script_mod._registered_libraries:
        _reg_mod = sys.modules.get(getattr(_reg_main, '__module__', ''))
        if _reg_mod is not None and _reg_mod is not script_module:
            sec_modules.append(_reg_mod)
    # Plain-OHLCV members of a MIXED group publish from the feed fields below,
    # before the clone runs, exactly as the fast path does for a context served
    # alone. Their write block in the clone would then publish a second time on
    # the same bar — and it carries whatever conditionals it had in ``main()``,
    # which is precisely what must not decide whether the value appears — so
    # they are left out of ``__active_security__`` and their block never fires.
    _pt_sids = [_sid for _sid in sec_ids if ohlcv_fields.get(_sid)]
    _mixed_pt_sids: frozenset[str] = (
        frozenset(_pt_sids) if 0 < len(_pt_sids) < len(sec_ids) else frozenset())
    for _sec_mod in sec_modules:
        inject_protocol(_sec_mod, signal_fn, write_fn, read_fn, wait_fn,
                        active_security=frozenset(sec_ids) - _mixed_pt_sids)

    # Fresh per-process state: drop anything inherited (fork start method) and
    # create the root state vectors of the entry points this process drives —
    # the script's main and the registered library mains (same binding rules
    # as the runner: state-carrying entries get a root vector as hidden first
    # argument, stateless ones are called as-is)
    instance_state.reset()
    main_func = script_module.main
    # Per-context backward slice of main(): an ordinary module-level function
    # with its own slot layout, so it becomes this process's entry point — root
    # vector, root key and every snapshot below refer to the clone, not to
    # main(). ``main_func`` stays the script entry the script metadata hangs on.
    entry_func = getattr(script_module, slice_main, None) if slice_main else None
    if entry_func is None:
        entry_func = main_func
    root_keys: list[str] = []
    seen_keys: set[str] = set()
    bound_entries: dict[int, Callable] = {}
    # noinspection PyProtectedMember
    for run_entry in [entry_func] + [f for _title, f in script_mod._registered_libraries]:
        if id(run_entry) in bound_entries:
            continue
        entry_layout = getattr(run_entry, '__pyne_layout__', None)
        if entry_layout is None:
            bound_entries[id(run_entry)] = run_entry
            continue
        entry_root_key = f'{run_entry.__module__}.{run_entry.__qualname__}'
        if entry_root_key in seen_keys:
            entry_root_key = f'{entry_root_key}#{len(root_keys)}'
        seen_keys.add(entry_root_key)
        root_keys.append(entry_root_key)
        bound_entries[id(run_entry)] = partial(
            run_entry, instance_state.create_root(entry_root_key, entry_layout))
    run_main = bound_entries[id(entry_func)]
    na_bool = main_func.script.na_bool

    # Set lib semaphore to suppress plot/strategy/alert side effects
    lib._lib_semaphore = True
    lib._in_security = True

    # noinspection PyProtectedMember
    def _run_script_main():
        """Mirror the chart's ``_run_libs_and_main``: registered library mains
        initialize their exported-function proxies, so they must run before the
        script's ``main()`` on every bar — otherwise a script that calls an
        imported library function dies here with "Exported proxy has not been
        initialized". ``lib._lib_semaphore`` stays True for both (every side
        effect is suppressed in a security child)."""
        # The script's bool na mode, re-applied on every entry (see ScriptRunner)
        set_bool_na(na_bool)
        for _title, _lib_main in script_mod._registered_libraries:
            bound_entries.get(id(_lib_main), _lib_main)()
        run_main()

    # Plain-OHLCV fast path: the requested expression is only raw price series,
    # all of which ``_set_lib_properties`` already wrote onto ``lib`` for the
    # current bar (byte-identical to what main() would read). Replace the per-bar
    # main() re-run with a direct write of those fields — every loop path
    # (historical, live developing/closed, live LTF window) calls
    # ``_run_script_main`` and so picks this up through the closure cell.
    # A GROUP replaces main() only when EVERY member is passthrough; one
    # computed member means the clone has to run. The passthrough members of
    # such a MIXED group still publish from the very same fields, ahead of the
    # clone: the value a context served alone publishes on every bar of its feed
    # cannot become conditional just because a sibling joined its child (their
    # write block in the clone is disabled for that reason, see
    # ``__active_security__`` above). Writing them FIRST is also what a sibling
    # depending on one of them reads out of the bar state.
    _pt_plan = tuple(
        (_sid, tuple(ohlcv_fields[_sid] or ()), bool(ohlcv_tuple.get(_sid)))
        for _sid in _pt_sids
    )
    if _pt_plan:
        _clone_main = _run_script_main
        _pt_only = not _mixed_pt_sids

        def _run_script_main():
            for _pt_sid, _pt_fields, _pt_is_tuple in _pt_plan:
                if _pt_is_tuple:
                    write_fn(_pt_sid,
                             tuple(getattr(lib, _f) for _f in _pt_fields))
                else:
                    write_fn(_pt_sid, getattr(lib, _pt_fields[0]))
            if not _pt_only:
                _clone_main()

    # Chart-type (Heikin Ashi) per-bar transform. The two carried HA values ride
    # a synthetic root vector whose var slots are captured/rolled back by the
    # existing ``RootVarSnapshot`` (create_root + root_keys.append) — so a
    # developing bar recomputes from the fixed prior-close baseline with no
    # bespoke logic. ``_ha_apply`` reads the baseline and returns the HA bar;
    # ``_ha_commit`` writes the new HA open/close AFTER ``_run_script_main()`` in
    # each branch (before any ``snap.save()``), so ``save()`` captures the
    # previous committed values and ``restore()`` rolls a re-tick back to them.
    # Registering the HA root also makes ``RootVarSnapshot.has_vars`` True for an
    # otherwise var-less plain-OHLCV context, activating the snapshot exactly
    # where the recurrence needs it.
    #
    # The float32 storage clean-up belongs to the feed values the recurrence
    # READS, so ``_ha_apply`` runs it itself and the emitted HA bar is then
    # handed to ``_set_lib_properties`` as ``derived_prices``: an HA candle is an
    # average, it does not sit on the mintick grid, and TradingView keeps its
    # full precision (measured on BINANCE:BTCUSDT 30m — snapping it to mintick
    # moved ``ta.ema(haClose, 34)`` by up to 2.2e-3, the raw average reproduces
    # TV's own plot to 1.5e-11).
    _derived_prices = chart_type == 'heikinashi'
    if chart_type == 'heikinashi':
        _ha_key = f'__heikinashi__{sec_id}'
        _ha_root = instance_state.create_root(_ha_key, {
            'init': (None, None), 'series': (), 'varip': (), 'children': (),
            'names': ('prevHaOpen', 'prevHaClose'),
        })
        root_keys.append(_ha_key)
        _ha_pending: 'list[float | None]' = [None, None]
        # The recurrence is seeded on the first bar rather than at setup, because
        # only then is the context's first bar timestamp known — and that is the
        # cut: every warmup bar STRICTLY BEFORE it advances the recurrence, the
        # first bar itself is the context's own and must be transformed by the
        # normal path. TradingView carries exactly this state into a context its
        # chart aggregates (measured on BINANCE:BTCUSDT@30: the ``"120"`` Heikin
        # Ashi context opens at ``bar_index`` 0 with the carried open, not with
        # ``(open + close) / 2``).
        _ha_needs_seed: 'list[bool]' = [chart_type_warmup is not None]

        def _ha_seed(_first_ts_ms: int) -> None:
            _ha_needs_seed[0] = False
            from .ohlcv import OHLCVReader
            _po: 'float | None' = None
            _pc: 'float | None' = None
            try:
                with OHLCVReader(str(chart_type_warmup)) as _reader:
                    for _wb in _reader:
                        if _wb.timestamp >= _first_ts_ms:
                            break
                        _wo, _, _, _wc = _heikinashi_step(
                            _po, _pc,
                            _round_price(_wb.open, round_decimals),
                            _round_price(_wb.high, round_decimals),
                            _round_price(_wb.low, round_decimals),
                            _round_price(_wb.close, round_decimals))
                        _po, _pc = _wo, _wc
            except (OSError, ValueError):
                # A missing or unreadable warmup feed is not worth failing the
                # run over: the recurrence simply stays cold, which is the
                # behaviour without a warmup feed at all.
                return
            if _po is not None:
                _ha_root[0], _ha_root[1] = _po, _pc

        def _ha_apply(_b: OHLCV) -> OHLCV:
            if _ha_needs_seed[0]:
                _ha_seed(_b.timestamp)
            if is_legacy_feed and _b.volume < 0:
                # Legacy gap-fill bar: forward-fill the last HA close flat and do
                # NOT advance the recurrence (mirrors the removed feed transform's
                # ``volume < 0`` skip).
                _fill = _ha_root[1] if _ha_root[1] is not None else _round_price(
                    _b.close, round_decimals)
                _ha_pending[0], _ha_pending[1] = _ha_root[0], _ha_root[1]
                return _b._replace(open=_fill, high=_fill, low=_fill, close=_fill)
            _ho, _hh, _hl, _hc = _heikinashi_step(
                _ha_root[0], _ha_root[1],
                _round_price(_b.open, round_decimals), _round_price(_b.high, round_decimals),
                _round_price(_b.low, round_decimals), _round_price(_b.close, round_decimals))
            _ha_pending[0], _ha_pending[1] = _ho, _hc
            return _b._replace(open=_ho, high=_hh, low=_hl, close=_hc)

        def _ha_commit() -> None:
            _ha_root[0], _ha_root[1] = _ha_pending[0], _ha_pending[1]
    else:
        def _ha_apply(_b: OHLCV) -> OHLCV:
            return _b

        def _ha_commit() -> None:
            pass

    # Set up file-based logging if PYNE_SECURITY_LOG is set
    security_log_path = os.environ.get("PYNE_SECURITY_LOG")
    if security_log_path:
        context_label = f"{syminfo.ticker} {syminfo.period}"
        from pynecore.lib.log import setup_security_file_log
        setup_security_file_log(security_log_path, context_label)

    # Snapshot of this process's root vectors' var slots — the rollback
    # baseline for live re-executions of the same HTF period.
    var_snapshot: instance_state.RootVarSnapshot | None = None

    # Companion series-slot snapshot, used ONLY by the live LTF-window path: a
    # reordered feed can make the collector replay an earlier LTF ``bar_index``
    # after a later one ran, which (unlike a same-index re-tick) would append to
    # the root price/history series instead of overwriting. ``RootVarSnapshot``
    # excludes series slots, so they get their own rollback. Captured only in the
    # live phase (the warmup path is forward-only and never restores), seeded at
    # the warmup->live transition so the first replay has a baseline.
    series_snapshot: instance_state.RootSeriesSnapshot | None = None

    # Companion to ``var_snapshot`` for the function instances. A re-tick of the
    # same HTF period is a discarded re-execution, and the next one must start
    # from the period baseline — including the builtin machines' internal state.
    # ``instance_state.reset()`` DROPS those instances instead of rolling them
    # back, so a stateful expression never accumulates across periods:
    # MEASURED (Saty ATR Levels, wild corpus) — ``ta.atr(14)`` inside a
    # ``lookahead_on`` security context stayed ``na`` on all 28366 bars.
    child_snapshot: instance_state.RootChildSnapshot | None = None

    # Tracks the last developing HTF period start (ms) the subprocess
    # advanced into. Used to distinguish "new dev period" (allocate a new
    # bar_index) from "another tick within the same dev period" (re-run
    # against the saved baseline).
    last_dev_period_start: int | None = None

    # A developing batch's records, produced one at a time while they are
    # replayed. The first one is pulled here: its tick is what the ring is
    # primed from, and every step needs to know the NEXT record's tick anyway
    # (see ``_dev_batch_steps``), so the iterator is kept one record ahead.
    dev_batch_records: 'Iterator[tuple] | None' = None
    dev_batch_next: 'tuple | None' = None
    # Ticks of the records replayed but not yet known to have been read by the
    # chart, for the run-ahead bound in ``_dev_batch_throttle``. Bounded by that
    # same bound plus one chart bar's records.
    dev_batch_pending: 'deque[int]' = deque()
    if dev_batch_spec is not None:
        dev_batch_records = iter_dev_batch_records(dev_batch_spec)
        dev_batch_next = next(dev_batch_records, None)
        if dev_batch_next is None:
            # The chart armed the batch because its window holds bars, and every
            # chart bar produces at least one record. An empty sequence means
            # this process reproduced a DIFFERENT window — fail here rather than
            # leave the chart waiting for rounds that will never come.
            raise RuntimeError(
                f"security context '{sec_id}': the developing batch window "
                f"'{dev_batch_spec.window.path}' produced no chart bars"
            )

    # Set after the first live bar has been consumed. The historical loop
    # leaves ``current_bar`` already pointing at the *next* unprocessed
    # security index, so the very first live bar (developing or closed
    # override) must reuse that slot. Only subsequent transitions between
    # distinct HTF periods advance ``current_bar``.
    seen_live_bar: bool = False

    def _ensure_snapshot() -> instance_state.RootVarSnapshot | None:
        nonlocal var_snapshot
        snapshot = var_snapshot
        if snapshot is None:
            snapshot = var_snapshot = instance_state.RootVarSnapshot(root_keys)
        return snapshot if snapshot.has_vars else None

    def _ensure_series_snapshot() -> instance_state.RootSeriesSnapshot | None:
        nonlocal series_snapshot
        snapshot = series_snapshot
        if snapshot is None:
            snapshot = series_snapshot = instance_state.RootSeriesSnapshot(root_keys)
        return snapshot if snapshot.has_series else None

    def _ensure_child_snapshot() -> instance_state.RootChildSnapshot:
        nonlocal child_snapshot
        if child_snapshot is None:
            child_snapshot = instance_state.RootChildSnapshot(root_keys)
        return child_snapshot

    # Append a streamer bar to ``bar_buffer``, deduped against ``last_warmup_ts``:
    # the WS was subscribed before the REST warmup ran, so the initial batch may
    # overlap the warmup tail (replace it) and anything older is a duplicate.
    def _ingest_streamer_bar(_bar: 'OHLCV') -> None:
        if last_warmup_ts is None:
            bar_buffer.append(_bar)
        elif _bar.timestamp == last_warmup_ts and bar_buffer:
            bar_buffer[-1] = _bar
        elif _bar.timestamp > last_warmup_ts:
            bar_buffer.append(_bar)

    # Polymorphic bar source: file-backed reader (random access on a static
    # ``.ohlcv``) or in-memory buffer fed by a live WS streamer (append-only,
    # grows over time as new closed bars arrive).
    def _read_bar(idx: int) -> 'OHLCV | None':
        if reader is not None:
            if real_index_map is not None:
                return reader.read(real_index_map[idx]) if idx < len(real_index_map) else None
            if idx < reader.size:
                return reader.read(idx)
            return None
        if live_streamer is not None:
            for _sb in live_streamer.pop_new_closed_bars():
                _ingest_streamer_bar(_sb)
        return bar_buffer[idx] if idx < len(bar_buffer) else None

    def _current_total() -> int:
        if reader is not None:
            return len(real_index_map) if real_index_map is not None else reader.size
        return len(bar_buffer)

    # ── Live LTF-window machinery (request.security_lower_tf on a streaming
    # source) ──────────────────────────────────────────────────────────────
    # A streaming LTF context accumulates each chart period's intrabars into a
    # window (closed intrabars plus the developing intrabar as the live last
    # element) via :class:`LiveLtfCollector`. Warmup replay (confirmed chart
    # bars) and live both flow through this one path; the collector owns the
    # monotonic LTF ``bar_index`` and the snapshot discipline, while ``_ltf_round``
    # supplies bars from this process's own streamer and publishes the window.
    ltf_next_idx = 0
    ltf_span_ms = 0
    ltf_phase_live = False
    ltf_series_base_armed = False
    _ltf_round: 'Callable[[int], None] | None' = None
    if (is_ltf and live_streamer is not None
            and isinstance(data_source, PluginSymbol)):
        from pynecore.lib.timeframe import _in_seconds
        assert ltf_take_value is not None and ltf_publish is not None
        _streamer = live_streamer
        _take_value = ltf_take_value
        _publish = ltf_publish
        ltf_span_ms = int(_in_seconds(data_source.timeframe) * 1000)

        # The REST warmup may end on a still-forming tail bar. On the window
        # path the developing intrabar must come ONLY from the live stream's
        # developing slot (re-run per tick), never from the closed buffer — a
        # forming tail left here would be consumed as a closed intrabar AND
        # surface again via ``peek_developing_bar``. Drop any such tail; the live
        # stream delivers it authoritatively (developing, then closed). Time
        # eligibility (period not ended by the warmup horizon) is the primary,
        # provider-agnostic test; the ``is_closed`` flag catches providers that
        # stamp it explicitly. WS closes consumed during the catch-up drain are
        # exempt: those bars were taken off the streamer queue and will not be
        # redelivered, so popping them would permanently lose intrabars that
        # closed during warmup. That covers both the equal-timestamp refinement
        # of the REST tail (``ws_refined_tail_ts``) and any later closes appended
        # past the REST tail (``timestamp > rest_warmup_tail_ts``) whose period
        # end can fall after ``warmup_horizon_ms`` — the horizon was sampled
        # before the warmup download, so a bar that closed mid-download would
        # otherwise look future-dated and be dropped despite being authoritative.
        rest_warmup_tail_ts = last_warmup_ts
        while bar_buffer and bar_buffer[-1].timestamp != ws_refined_tail_ts and not (
                rest_warmup_tail_ts is not None
                and bar_buffer[-1].timestamp > rest_warmup_tail_ts) and (
                not bar_buffer[-1].is_closed
                or bar_buffer[-1].timestamp + ltf_span_ms > warmup_horizon_ms):
            bar_buffer.pop()
        last_warmup_ts = bar_buffer[-1].timestamp if bar_buffer else None

        def _run_ltf_intrabar(intrabar, bar_index, confirmed, is_new, islast):
            _set_lib_properties(intrabar, bar_index, tz, round_decimals,
                                lossless_volume=lossless_volume,
                                lossless_prices=lossless_prices)
            lib.last_bar_index = float(bar_index)
            barstate.isfirst = (bar_index == 0)
            barstate.islast = islast
            barstate.isconfirmed = confirmed
            barstate.ishistory = not ltf_phase_live
            barstate.isrealtime = ltf_phase_live
            barstate.islastconfirmedhistory = False
            barstate.isnew = is_new
            _run_script_main()
            return _take_value()

        def _save_ltf_baseline():
            _snap = _ensure_snapshot()
            if _snap is not None:
                _snap.save()
            _ensure_child_snapshot().save()
            # Series rollback is needed only in the live phase, where a reordered
            # feed can trigger a backward replay; the warmup path is forward-only
            # and never restores, so copying buffers there would be wasted work.
            if ltf_phase_live:
                _ss = _ensure_series_snapshot()
                if _ss is not None:
                    _ss.save()

        def _restore_ltf_baseline():
            _snap = _ensure_snapshot()
            if _snap is not None:
                _snap.restore()
            if series_snapshot is not None and series_snapshot.saved:
                series_snapshot.restore()
            _ensure_child_snapshot().restore()

        _ltf_collector = LiveLtfCollector(
            _run_ltf_intrabar, _save_ltf_baseline, _restore_ltf_baseline,
        )

        def _ltf_round(slot_flags: int) -> None:
            nonlocal ltf_next_idx, ltf_phase_live, ltf_series_base_armed
            period_start = sync_block.get_target_time(sec_id)
            period_end_exclusive = sync_block.get_ltf_period_end(sec_id)
            chart_developing = is_ltf_chart_developing(slot_flags)
            chart_confirmed = not chart_developing
            ltf_phase_live = is_ltf_live_phase(slot_flags)

            # Seed the series baseline once, on the warmup->live transition: the
            # warmup ran forward-only so the series now hold exactly the confirmed
            # prefix, and the first live replay's restore needs that baseline even
            # if it precedes the first live confirmed save.
            if ltf_phase_live and not ltf_series_base_armed:
                _ss = _ensure_series_snapshot()
                if _ss is not None:
                    _ss.save()
                ltf_series_base_armed = True

            for _sb in _streamer.pop_new_closed_bars():
                _ingest_streamer_bar(_sb)

            # Collect not-yet-consumed closed intrabars up to the period end
            # (future-period bars are deferred). On a confirmed chart bar the
            # published array must be the FULL closed period, so wait (bounded)
            # for the final in-period intrabar if the streamer lags — a no-op
            # during warmup, where the REST bars are already buffered.
            collected, ltf_next_idx = _collect_in_period_intrabars(
                bar_buffer, ltf_next_idx, period_end_exclusive, ltf_span_ms,
                chart_developing, live_bar_grace_seconds,
                _streamer.wait_for_bars, _ingest_streamer_bar,
            )

            developing_bar: 'OHLCV | None' = None
            if chart_developing:
                _dev = _streamer.peek_developing_bar()
                # Only a forming bar strictly after the last collected closed
                # intrabar is a live developing tail; a stale tick at/under it
                # (e.g. a late forming update for an already-closed intrabar)
                # would otherwise allocate a spurious new bar_index.
                _last_collected_ms = (
                    collected[-1].timestamp if collected else period_start - 1
                )
                if _dev is not None:
                    _dev_ms = _dev.timestamp
                    if _last_collected_ms < _dev_ms < period_end_exclusive:
                        developing_bar = _dev
                    else:
                        logger.debug(
                            "LTF developing tick ts=%d ms outside (%d, %d) — skipped",
                            _dev_ms, _last_collected_ms, period_end_exclusive,
                        )

            window_values = _ltf_collector.process_round(
                period_start, period_end_exclusive, collected,
                developing_bar, chart_confirmed=chart_confirmed,
            )
            _publish(window_values)

    # Fixed ``last_bar_time`` anchor for file-backed (historical) runs: Pine
    # fixes it to the security series' final bar, known up front from the
    # static file. On a legacy feed, scan back over its gap-fill tail
    # (``volume == -1`` records; ``not (volume < 0)`` keeps NaN-volume real
    # bars) — a no-op when ``real_index_map`` already compacted the gaps away.
    # Streamer-fed (live) contexts keep the per-bar value from
    # ``_set_lib_properties``: the realtime bar IS the last bar there.
    file_last_bar_time_ms = 0
    if reader is not None:
        for _pos in range(_current_total() - 1, -1, -1):
            _tail_bar = _read_bar(_pos)
            if _tail_bar is None:
                continue
            if is_legacy_feed and _tail_bar.volume < 0:
                continue
            file_last_bar_time_ms = _tail_bar.timestamp
            break

    def _set_series_end(bar_idx: int, is_history: bool) -> None:
        """Point ``last_bar_index``/``last_bar_time`` at the end of this series.

        A HISTORICAL developing (or closed-override) period sits in the middle of a
        file-backed run, so the series' end is the file's final bar, not the period
        being replayed — the same anchor the historical loop below uses. Walking them
        back to the current period makes ``barstate``/``chart.right_visible_bar_time``
        fire on every bar instead of once. At the live edge the current bar IS the
        last one, and a streamer-fed context has no file end to anchor to.

        :param bar_idx: Index of the bar being run
        :param is_history: True while the period replayed is historical
        """
        if is_history and reader is not None:
            lib.last_bar_index = float(_current_total() - 1)
            lib.last_bar_time = file_last_bar_time_ms
        else:
            lib.last_bar_index = float(bar_idx)

    def _bar_open_at(idx: int) -> int:
        """Open instant (ms) of the source bar at ``idx``, 0 past the end."""
        src_bar = _read_bar(idx)
        return 0 if src_bar is None else src_bar.timestamp

    def _next_frontier(upcoming_open: int, upcoming2_open: int) -> int:
        """Frontier close to publish with the bar preceding ``upcoming_open``.

        "Every bar of mine closing at or before this is already in the ring" —
        that is the next UNPUBLISHED bar's scheduled close minus one ms. A static
        file that has run out has no next bar at all, so its producer is done and
        the frontier goes to ``+inf``; a streaming source instead assumes the
        schedule's next bar, which is what the chart will target next.
        """
        if upcoming_open:
            return actual_bar_close(upcoming_open, upcoming2_open, own_calendar,
                                    own_timeframe) - 1
        if reader is not None:
            return FRONTIER_INF
        return actual_bar_close(sec_ctx.bar_close, 0, own_calendar,
                                own_timeframe) - 1

    def _capped_frontier(frontier: int) -> int:
        """Hold a closed round's frontier inside the round's own as-of.

        The bar grid alone would let a closed round claim everything up to the
        next scheduled close, but the ring also carries DEVELOPING entries, and
        those close AT their round's tick — inside exactly that window. The
        frontier only ever rises, so a wider claim here would tell a consumer
        running on a later tick that the round it waits for is already
        published, and it would read this round's value instead.

        The cap is how far a consumer of this round can ask: the round's tick,
        or the end of the scheduled break containing it for a D/W/M context
        keeping the chart's calendar (:func:`chart_asof`). Nothing asks beyond
        it, so capping never holds a consumer back. A round with no tick (no
        chart bar cycle, as in unit tests) is left uncapped.

        A closed BATCH round is the exception -- see the first branch. A
        DEVELOPING batch is NOT: its steps are replayed per planned chart bar,
        each carrying that bar's own tick, so the per-round cap below is exactly
        what each of them needs (and what the per-bar path gave it). Publishing
        such a step uncapped would tell the chart that a later bar's entry is
        already in the ring, and it would pair that bar with this step's value.

        One chart bar can queue SEVERAL rounds for this context, all carrying
        the same tick: a prefill and/or a closed bar, then the developing bar
        that appends AT the tick. While such a step is still pending
        (``FLAG_MORE_STEPS``), this round must stay strictly below the tick —
        a consumer released at the tick by an intermediate step would pair with
        this step's entry instead of waiting for the developing one, and the
        dependent form would diverge from the nested one. MEASURED on a daily
        chart with a weekly context and on an intraday chart missing the
        period-closing bar: ``HTFAggregator.update()`` returns the closed AND
        the developing bar in the same call there, so the two steps share a
        round. Nothing deadlocks: the chart always drives the queue to its last
        step within the same chart bar, and that step publishes uncapped.

        :param frontier: Frontier close the bar grid suggests, in ms.
        :return: The frontier to publish, in ms.
        """
        if batch_round:
            # A batch round runs the whole historical phase in one go and
            # carries no developing entry, so nothing of it can be read too
            # early -- the ring pairs by close and a consumer never asks beyond
            # its own as-of. It MUST publish uncapped: the chart's per-bar ring
            # waits are released by this frontier, and a cap at the launching
            # bar's tick would stall every later bar forever.
            return frontier
        if more_steps and sec_ctx.round_tick:
            cap = sec_ctx.round_tick - 1
        else:
            cap = sec_ctx.round_sched_next_open or sec_ctx.round_tick
        if cap and frontier > cap:
            return cap
        return frontier

    def _developing_frontier() -> int:
        """How far a developing round publishes.

        The round's tick — the instant the developing entry carries as its close
        — except for a D/W/M context keeping the CHART's calendar, which is read
        as far as the end of the scheduled break the tick falls in: the chart
        derives that as-of with :func:`chart_asof` (and settles a context it does
        NOT launch to exactly it), a peer child with ``_peer_asof``. A weekly
        context on a daily equity chart is therefore asked for Thursday 09:30 on
        the Wednesday bar closing at 16:00, and stopping the frontier at 16:00
        would leave that consumer waiting forever for an instant no round of this
        context ever reaches. Every other context is asked no further than the
        tick, so it publishes no further either.

        :return: The frontier to publish with the developing entry, in ms.
        """
        if own_dwm_on_chart_calendar and sec_ctx.round_sched_next_open:
            return sec_ctx.round_sched_next_open
        return sec_ctx.round_tick

    # False while a developing-batch round still has records to replay: the
    # chart counts ROUNDS, and the whole planned sequence is ONE round of its.
    round_is_last_step = [True]

    def _release_round() -> None:
        """Wake the chart for this step, unless the step's last write already did.

        The write releases the chart early, while ``main()`` still runs; the
        chart may then launch its next step at once. Waking it again here would
        answer that next step's wait with this step's value. Per member, since
        the chart waits on each context's own ``data_ready``.
        """
        release_unwritten()

    def _end_round() -> None:
        """Close the round: the chart's "one round outstanding" counter, then
        the wake-up. The counter, not the event, is what lets a chart bar keep
        several rounds of one context in flight without mixing their slots.
        Raised for EVERY member: the chart settles each context on its own
        counter, whether or not this process serves it alone."""
        if not round_is_last_step[0]:
            return
        for member in sec_ids:
            sync_block.increment_rounds_done(member)
            done_event_map[member].set()

    def _chart_driven_step(slot_flags: int) -> 'Iterator[tuple]':
        """The one step of an ordinary round: whatever the chart put in the slot.

        The round context is unpacked HERE, once: the chart may already be
        writing the next round's slot while this round's bars still run, so
        every as-of of the round must come from these two values and not from a
        later re-read.

        :param slot_flags: The slot's flags, read by the caller.
        :return: A one-item iterator of ``(target_time, flags, more_steps,
            dev_values)``; ``dev_values`` is ``None`` — the pushed OHLCV is read
            from the slot.
        """
        sec_ctx.round_tick, sec_ctx.round_sched_next_open = (
            sync_block.get_round_context(sec_id))
        target_time = sync_block.get_target_time(sec_id)
        if authoritative_observations:
            closed, developing, historical = live_streamer.refresh(target_time, sec_ctx.round_tick)
            if closed and not historical and not is_ltf:
                for index, bar in enumerate(live_streamer.pop_new_closed_bars()):
                    _ingest_streamer_bar(bar)
                    following = index + 1 < len(closed) or developing is not None
                    round_is_last_step[0] = not following
                    flags = (slot_flags | FLAG_CLOSED_OVERRIDE) & ~(FLAG_IS_DEVELOPING | FLAG_DEV_HISTORICAL)
                    if following:
                        flags |= FLAG_MORE_STEPS
                    yield (bar.timestamp, flags, following or bool(slot_flags & FLAG_MORE_STEPS), bar)
                if developing is None:
                    return
            if developing is not None and not is_ltf:
                round_is_last_step[0] = True
                dev_flags = (slot_flags | FLAG_IS_DEVELOPING) & ~FLAG_CLOSED_OVERRIDE
                if historical:
                    dev_flags |= FLAG_DEV_HISTORICAL
                else:
                    dev_flags &= ~FLAG_DEV_HISTORICAL
                yield (developing.timestamp, dev_flags, bool(slot_flags & FLAG_MORE_STEPS), developing)
                return
            if not historical and not is_ltf:
                # No qualifying observation may commit a forming baseline.
                sec_ctx.released.clear()
                round_is_last_step[0] = True
                for member in sec_ids:
                    with result_locks[member]:
                        write_na(result_blocks[member], sync_block)
                _release_round()
                _end_round()
                return
        round_is_last_step[0] = True
        yield (target_time, slot_flags, bool(slot_flags & FLAG_MORE_STEPS), None)

    def _dev_batch_steps() -> 'Iterator[tuple]':
        """Replay a planned developing-batch sequence, one record per step.

        Each record IS a round the per-bar path would have launched, with its
        own chart tick and scheduled next session open — so the flags are
        synthesized from the record kind rather than read from the slot, and the
        round context comes from the record. ``FLAG_DEV_BATCH_ROUND`` itself is
        deliberately NOT passed on: the frontier of every step has to stay
        inside its own bar's tick (unlike a closed batch, which publishes
        uncapped), and the per-round caps in ``_capped_frontier`` already do
        exactly that.

        The records of ONE chart bar share a tick, and all but the last of them
        carry ``FLAG_MORE_STEPS`` for the same reason they do per bar: a
        consumer released at the tick by the closed step would pair with it
        instead of with the developing entry that lands at the very same
        instant.

        :return: Iterator of ``(target_time, flags, more_steps, dev_values)``.
        """
        nonlocal dev_batch_next
        records = dev_batch_records
        assert records is not None
        prev_tick = -1
        record = dev_batch_next
        while record is not None:
            (kind, period_start, r_open, r_high, r_low, r_close, r_volume,
             tick, sched_next_open) = record
            # One record of lookahead: whether this step is the last one of its
            # chart bar (and of the whole sequence) is a property of the NEXT
            # record, so the iterator always stands one record ahead.
            following = next(records, None)
            dev_batch_next = following
            if tick != prev_tick:
                # A fresh chart bar: do not run further ahead of the chart than
                # the ring is allowed to hold.
                _dev_batch_throttle()
                prev_tick = tick
            dev_batch_pending.append(tick)
            sec_ctx.round_tick = tick
            sec_ctx.round_sched_next_open = sched_next_open
            if kind == DEV_BATCH_DEVELOPING:
                step_flags = FLAG_IS_DEVELOPING | FLAG_DEV_HISTORICAL
                step_values = (r_open, r_high, r_low, r_close, r_volume,
                               period_start)
            elif kind == DEV_BATCH_CLOSED:
                step_flags = FLAG_CLOSED_OVERRIDE | FLAG_DEV_HISTORICAL
                step_values = (r_open, r_high, r_low, r_close, r_volume,
                               period_start)
            else:
                # Prefill: the child reads its OWN file up to this target, the
                # closed periods that precede the first containing one.
                step_flags = 0
                step_values = None
            more = following is not None and following[7] == tick
            if more:
                step_flags |= FLAG_MORE_STEPS
            round_is_last_step[0] = following is None
            yield period_start, step_flags, more, step_values
            record = following

    def _dev_batch_throttle() -> None:
        """Keep the batch from running unboundedly far ahead of the chart.

        The ring writer never blocks on space — it grows — so a child replaying
        a million-bar sequence while the chart is still on bar one would hold a
        million entries. The chart parks its watermark at each bar's as-of
        before it waits, which is exactly how far it has read, so the run-ahead
        is measurable and can be bounded.

        ``dev_batch_pending`` holds the ticks of the records replayed since the
        chart's watermark was last consulted; its length IS the run-ahead, and
        dropping its head below the watermark is how far the chart has read.

        Once the bound is reached the wait runs until the run-ahead is back down
        to :data:`RING_RESUME_ENTRIES`, and the producer publishes that it is
        parked so the chart's watermark park notifies it. Both halves matter: a
        producer that resumed at the bound would re-park on the very next
        record, and one the chart does not know about would only be released by
        the liveness recheck below.
        """
        if len(dev_batch_pending) < RING_RUNAHEAD_ENTRIES:
            # Not far enough ahead of anything: skip even the condition acquire.
            # It is contended — the chart holds the same condition while it
            # evaluates its ring waits — and this runs per chart bar.
            return
        cond = ring_conditions.get(sec_id) if ring_conditions else None
        if cond is None:
            dev_batch_pending.clear()
            return
        own = sync_block.index_of(sec_id)
        chart_idx = sync_block.chart_index
        with cond:
            try:
                while True:
                    watermark = sync_block.get_watermark(chart_idx, own)
                    while dev_batch_pending and dev_batch_pending[0] <= watermark:
                        dev_batch_pending.popleft()
                    if (len(dev_batch_pending) < RING_RESUME_ENTRIES
                            or stop_event.is_set()):
                        return
                    # What this wait needs: the chart has to have read past the
                    # record that brings the run-ahead back under the resume
                    # level. Published BEFORE the next look at the watermark, so
                    # a chart parking its own watermark from here on cannot slip
                    # between the two and leave this producer unwoken.
                    sync_block.set_parked_until(
                        sec_id,
                        dev_batch_pending[len(dev_batch_pending) - RING_RESUME_ENTRIES])
                    if sync_block.get_watermark(chart_idx, own) != watermark:
                        continue
                    cond.wait(_DEV_BATCH_WAIT_SECONDS)
            finally:
                sync_block.set_parked_until(sec_id, 0)

    try:
        current_bar = 0
        if reader is not None:
            # The frontier this producer starts with: its first bar has not been
            # published yet, so everything closing before that bar's close is
            # already (vacuously) in the ring. A consumer whose own first bars
            # close before this context's first one is released by it without
            # the chart ever having to wake this producer.
            if dev_batch_next is not None:
                # A developing batch's entries do NOT close on this context's own
                # bar grid — each closes at the CHART tick of the bar it was
                # planned for, and the first of those lies inside this context's
                # first period, far below its close. Priming from the bar grid
                # would claim every chart tick of that first period as published
                # and the chart would pair its first bars against an empty ring.
                prime_ring(dev_batch_next[7] - 1)
            else:
                _first_open = _bar_open_at(0)
                if _first_open:
                    prime_ring(actual_bar_close(_first_open, _bar_open_at(1),
                                                own_calendar, own_timeframe) - 1)

        while True:
            # Wait for chart to signal this process
            advance_event.wait()
            advance_event.clear()

            # Check for shutdown
            if stop_event.is_set():
                break

            # ONE chart round is normally ONE step. A historical developing
            # batch is the exception: the chart launches a single round for the
            # whole planned sequence and this process replays every record in it
            # as a step of its own, each with the chart tick of the bar it was
            # planned for. The step bodies below are unchanged by which of the
            # two produced them — a ``continue`` in one of them moves on to the
            # next step, which for a batch is the next record.
            round_flags = sync_block.get_flags(sec_id)
            if dev_batch_records is not None and (round_flags & FLAG_DEV_BATCH_ROUND):
                round_steps = _dev_batch_steps()
                dev_batch_running = True
            else:
                round_steps = _chart_driven_step(round_flags)
                dev_batch_running = False

            for target_time, flags, more_steps, dev_values in round_steps:
                sec_ctx.released.clear()
                batch_round = bool(flags & FLAG_BATCH_ROUND)
                is_developing = bool(flags & FLAG_IS_DEVELOPING)
                closed_override = bool(flags & FLAG_CLOSED_OVERRIDE)
                # ``Lookahead.ON`` uses the pushed-OHLCV transport in historical
                # mode too (the child's file holds the containing period's COMPLETE
                # bar, which would leak the future). The transport is the live one,
                # the chart bar is not — so the phase comes from the flag, not from
                # the fact that OHLCV arrived over the SyncBlock.
                dev_is_history = bool(flags & FLAG_DEV_HISTORICAL)

                # ── (4) Live LTF window round ──
                # Checked first: a streaming request.security_lower_tf round carries
                # its own flag and never the HTF developing/closed-override flags.
                if _ltf_round is not None and is_ltf_window(flags):
                    _ltf_round(flags)
                    _release_round()
                    _end_round()
                    continue

                # ── (3) Live developing bar ──
                if is_developing:
                    if isinstance(dev_values, OHLCV):
                        ohlcv = dev_values
                        dev_time_ms = ohlcv.timestamp
                    else:
                        if dev_values is None:
                            (dev_open, dev_high, dev_low, dev_close, dev_volume,
                             dev_time_ms) = sync_block.get_developing_bar(sec_id)
                        else:
                            (dev_open, dev_high, dev_low, dev_close, dev_volume,
                             dev_time_ms) = dev_values
                        ohlcv = OHLCV(timestamp=dev_time_ms,
                            open=dev_open, high=dev_high, low=dev_low,
                            close=dev_close, volume=dev_volume)

                    # A developing bar publishes only as far as the round's as-of
                    # (``_developing_frontier``): the tick instant is exactly how
                    # much of it has aggregated and the close its ring entry carries.
                    # Claiming the bar's own scheduled close would tell a consumer
                    # running on a LATER tick that this round is already published,
                    # and it would read the previous tick's value instead of waiting
                    # for its own. The chart raises the frontier of a producer it
                    # does not launch, so nothing waits on a round that never comes.
                    sec_ctx.bar_open = dev_time_ms
                    sec_ctx.bar_close = actual_bar_close(dev_time_ms, 0, own_calendar,
                                                         own_timeframe)
                    sec_ctx.frontier = _developing_frontier()
                    sec_ctx.developing = True
                    sec_ctx.is_round_last = True

                    is_new_dev_period = (last_dev_period_start != dev_time_ms)
                    if is_new_dev_period:
                        # Step the subprocess into a fresh bar slot — but reuse
                        # the slot already pointed at by ``current_bar`` for the
                        # very first live bar (the historical loop leaves it on
                        # the next unprocessed index).
                        if seen_live_bar:
                            current_bar += 1
                        seen_live_bar = True
                        last_dev_period_start = dev_time_ms
                    else:
                        # Same dev period: restore var globals AND the function
                        # instances to the period baseline (saved either after the
                        # prior closed run or at the start of this dev period) and
                        # re-run.
                        snap = _ensure_snapshot()
                        if snap is not None:
                            snap.restore()
                        _ensure_child_snapshot().restore()

                    _set_lib_properties(_ha_apply(ohlcv), current_bar, tz, round_decimals,
                                        lossless_volume=lossless_volume,
                                        lossless_prices=lossless_prices,
                                        derived_prices=_derived_prices)
                    _set_series_end(current_bar, dev_is_history)

                    barstate.isfirst = (current_bar == 0)
                    # Only the developing period at the live edge is the chart's last bar.
                    # A historical developing period sits in the middle of the run, and
                    # claiming ``islast`` there fires every ``if barstate.islast`` block on
                    # EVERY chart bar -- including on the child's first, where the arrays
                    # such a block indexes hold a single element.
                    barstate.islast = not dev_is_history
                    barstate.isconfirmed = False
                    barstate.ishistory = dev_is_history
                    barstate.isrealtime = not dev_is_history
                    barstate.islastconfirmedhistory = False
                    barstate.isnew = is_new_dev_period

                    if is_new_dev_period:
                        snap = _ensure_snapshot()
                        if snap is not None:
                            snap.save()
                        _ensure_child_snapshot().save()

                    _run_script_main()
                    # Commit the developing HA open/close AFTER the run and the
                    # new-period ``save()`` above; a same-period re-tick's
                    # ``snap.restore()`` rolls these back to the period baseline.
                    _ha_commit()

                    after_bar()
                    _release_round()
                    _end_round()
                    continue

                # ── (2) Live closed bar (OHLCV from SyncBlock) ──
                if closed_override:
                    if isinstance(dev_values, OHLCV):
                        ohlcv = dev_values
                        dev_time_ms = ohlcv.timestamp
                    else:
                        if dev_values is None:
                            (dev_open, dev_high, dev_low, dev_close, dev_volume,
                             dev_time_ms) = sync_block.get_developing_bar(sec_id)
                        else:
                            (dev_open, dev_high, dev_low, dev_close, dev_volume,
                             dev_time_ms) = dev_values
                        ohlcv = OHLCV(timestamp=dev_time_ms,
                            open=dev_open, high=dev_high, low=dev_low,
                            close=dev_close, volume=dev_volume)

                    sec_ctx.bar_open = dev_time_ms
                    sec_ctx.bar_close = actual_bar_close(dev_time_ms, 0, own_calendar,
                                                         own_timeframe)
                    sec_ctx.frontier = _capped_frontier(actual_bar_close(
                        sec_ctx.bar_close, 0, own_calendar, own_timeframe) - 1)
                    sec_ctx.developing = False
                    sec_ctx.is_round_last = True

                    # TV semantics: a developing HTF bar and its eventual close
                    # share the same security-series index (Series.add() degrades
                    # to set() because the bar_index hasn't moved). Only allocate
                    # a NEW bar_index when this closed bar is not the closing of
                    # an in-flight dev period (e.g. live closed bar arriving with
                    # no prior dev — currently unused, but kept correct). The
                    # very first live bar reuses the next-unprocessed index the
                    # historical loop left in ``current_bar``.
                    if last_dev_period_start == dev_time_ms:
                        # Same HTF bar — restore the var and instance baseline,
                        # then re-run as confirmed close. Series writes overwrite
                        # the dev value.
                        snap = _ensure_snapshot()
                        if snap is not None:
                            snap.restore()
                        _ensure_child_snapshot().restore()
                        is_new_closed_period = False
                    else:
                        if seen_live_bar:
                            current_bar += 1
                        seen_live_bar = True
                        is_new_closed_period = True

                    last_dev_period_start = None

                    _set_lib_properties(_ha_apply(ohlcv), current_bar, tz, round_decimals,
                                        lossless_volume=lossless_volume,
                                        lossless_prices=lossless_prices,
                                        derived_prices=_derived_prices)
                    _set_series_end(current_bar, dev_is_history)
                    barstate.isfirst = (current_bar == 0)
                    barstate.islast = False
                    barstate.isconfirmed = True
                    barstate.ishistory = dev_is_history
                    barstate.isrealtime = not dev_is_history
                    barstate.islastconfirmedhistory = False
                    barstate.isnew = is_new_closed_period

                    _run_script_main()
                    # Commit the closed HA open/close BEFORE the baseline ``save()``
                    # below, so the confirmed values become the next period's seed.
                    _ha_commit()

                    # Snapshot AFTER the closed run completes — baseline for
                    # subsequent developing iterations of the next HTF period.
                    snap = _ensure_snapshot()
                    if snap is not None:
                        snap.save()
                    _ensure_child_snapshot().save()

                    after_bar()
                    _release_round()
                    _end_round()
                    continue

                # Historical path resets dev-period tracking.
                last_dev_period_start = None

                # ── (1) Historical / cross-symbol-live closed bar from local source ──
                # In cross-symbol live mode (``live_streamer is not None``), the
                # upstream WS feed may publish the requested symbol's closed bar
                # a few seconds after the chart symbol's close. The chart side
                # has already advanced ``last_confirmed = target_time`` and will
                # not re-signal this period, so we must block briefly until the
                # bar arrives instead of falling through to ``write_na``.
                bars_run = False
                # File-backed LTF: values written while replaying feed bars that
                # CLOSE at or before the chart bar's period start (cold start
                # mid-feed, chart session gaps, intrabars already delivered to an
                # earlier chart bar) are expression-state warmup, not array content.
                # An intrabar straddling the period start closed inside this period
                # and therefore belongs to this array — it was pushed over from the
                # previous chart bar, whose close it passed.
                ltf_period_start = (
                    sync_block.get_ltf_period_start(sec_id) if is_ltf else 0
                )
                ltf_prefix_len = 0
                grace_deadline: float | None = None
                if live_streamer is not None:
                    grace_deadline = monotonic() + live_bar_grace_seconds
                while True:
                    ohlcv_file_bar = _read_bar(current_bar)
                    if ohlcv_file_bar is None:
                        if grace_deadline is not None and live_streamer is not None:
                            remaining = grace_deadline - monotonic()
                            if remaining > 0:
                                # Block on the streamer queue for the new bar.
                                # ``_read_bar`` only consults the streamer when
                                # ``current_bar >= len(bar_buffer)``, so any
                                # bars returned here are appended to the buffer
                                # via ``_read_bar`` on the next iteration.
                                new_bars = live_streamer.wait_for_bars(remaining)
                                if new_bars:
                                    for _bar in new_bars:
                                        if last_warmup_ts is None:
                                            bar_buffer.append(_bar)
                                        elif (_bar.timestamp == last_warmup_ts
                                                and bar_buffer):
                                            bar_buffer[-1] = _bar
                                        elif _bar.timestamp > last_warmup_ts:
                                            bar_buffer.append(_bar)
                                    continue
                        break
                    # A UTC->tz datetime roundtrip preserves the instant, so the
                    # raw timestamp is already the answer
                    bar_time_ms = ohlcv_file_bar.timestamp
                    if bar_time_ms > target_time:
                        break

                    next_open = _bar_open_at(current_bar + 1)
                    sec_ctx.bar_open = bar_time_ms
                    sec_ctx.bar_close = actual_bar_close(
                        bar_time_ms, next_open, own_calendar, own_timeframe)
                    sec_ctx.frontier = _capped_frontier(_next_frontier(
                        next_open, _bar_open_at(current_bar + 2) if next_open else 0))
                    sec_ctx.developing = False
                    # The round's LAST bar releases the chart AT THE WRITE, not at
                    # the end of ``main()``: a peer read standing after the write
                    # must not be able to hold the chart up.
                    sec_ctx.is_round_last = not next_open or next_open > target_time

                    total_bars = _current_total()
                    _set_lib_properties(_ha_apply(ohlcv_file_bar), current_bar, tz, round_decimals,
                                        lossless_volume=lossless_volume,
                                        lossless_prices=lossless_prices,
                                        derived_prices=_derived_prices)
                    lib.last_bar_index = float(total_bars - 1)
                    if reader is not None:
                        lib.last_bar_time = file_last_bar_time_ms
                    barstate.isfirst = (current_bar == 0)
                    barstate.islast = (current_bar == total_bars - 1)
                    barstate.isconfirmed = True
                    # In PluginSymbol mode, bars beyond the warmup tail come from
                    # the live WS streamer and represent realtime closes. Without
                    # a phase flip here, ``barstate.ishistory`` would stay ``True``
                    # for streamed closed bars — diverging from the same-symbol
                    # live path (see lines 511-513 and 568-570 above) and breaking
                    # script branches that key off ``barstate.isrealtime``.
                    if (live_streamer is not None
                            and last_warmup_ts is not None
                            and ohlcv_file_bar.timestamp > last_warmup_ts):
                        barstate.ishistory = False
                        barstate.isrealtime = True

                    _run_script_main()
                    # Advance the HA recurrence for this confirmed bar; the batch
                    # ``save()`` below captures the last bar's HA as the baseline.
                    _ha_commit()

                    after_bar()

                    if is_ltf and sec_ctx.bar_close <= ltf_period_start:
                        ltf_prefix_len = ltf_buffer_len()  # noqa - non-None when is_ltf
                    current_bar += 1
                    bars_run = True

                if bars_run:
                    snap = _ensure_snapshot()
                    if snap is not None:
                        snap.save()
                    _ensure_child_snapshot().save()

                if is_ltf:
                    flush_fn(ltf_prefix_len)
                elif not bars_run and not plain_ltf:
                    # No bar of this feed ran, so no member wrote: each of them
                    # publishes ``na``, exactly as a context served alone does.
                    for _member in sec_ids:
                        with result_locks[_member]:
                            write_na(result_blocks[_member], sync_block)

                _release_round()
                _end_round()

            if dev_batch_running:
                # The plan covers every chart bar, so nothing of this context
                # will ever be asked for again: the producer is done. Saying so
                # releases the chart's remaining ring waits — a chart bar whose
                # own record was the plan's last one has no later publication to
                # raise the frontier past its as-of.
                finish_ring()

    finally:
        # Whatever ended this loop — a shutdown, an exception, the end of the
        # feed — release anyone still waiting on this round. A sibling's death
        # sets EVERY child's stop_event, so this child can leave with a round
        # outstanding; it then exits cleanly, its own watcher fires nothing,
        # and an untimed chart wait on these events would never wake.
        for _member in sec_ids:
            data_ready_events[_member].set()
            done_event_map[_member].set()
        finish_ring()
        cleanup()
        if reader is not None:
            reader.close()
        if live_streamer is not None:
            live_streamer.stop()
        for _block in result_blocks.values():
            _block.close()
        sync_block.close()
        lib._lib_semaphore = False
        lib._in_security = False
